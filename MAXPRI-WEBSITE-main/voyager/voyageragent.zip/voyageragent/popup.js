const chatContainer = document.getElementById("chatContainer");
const objectiveInput = document.getElementById("objectiveInput");
const startButton = document.getElementById("startButton");
const stopButton = document.getElementById("stop-btn");
const micButton = document.getElementById("micButton");
const authButton = document.getElementById("authButton");
const userName = document.getElementById("userName");
const userAvatar = document.getElementById("userAvatar");
const agentStateContainer = document.getElementById("agent-state-container");
const idleStateContainer = document.getElementById("idle-state-container");
const chatList = document.getElementById("chatList");
const newChatButton = document.getElementById("newChatButton");
const toggleSidebarButton = document.getElementById("toggleSidebarButton");
const continueChatButton = document.getElementById("continueChatButton");
const chatTitle = document.getElementById("chatTitle");

let currentUser = null;
let googleAccessToken = null;
let chats = [];
let activeChatId = null;
let continueCurrentChat = true;

chrome.storage.local.get(["sidebarCollapsed"], (data) => {
  setSidebarCollapsed(data.sidebarCollapsed === true);
});

function setSidebarCollapsed(collapsed) {
  document.querySelector(".app-shell").classList.toggle("sidebar-collapsed", collapsed);
  toggleSidebarButton.innerHTML = collapsed ? "&#8250;" : "&#8249;";
  toggleSidebarButton.title = collapsed ? "Expand chats" : "Collapse chats";
  toggleSidebarButton.setAttribute("aria-label", toggleSidebarButton.title);
}

function requestFreshGoogleAccessToken() {
  return new Promise((resolve) => {
    chrome.identity.clearAllCachedAuthTokens(() => {
      chrome.identity.getAuthToken({ interactive: true }, (token) => {
        const authError = chrome.runtime.lastError;
        if (authError || !token) {
          console.error("Authentication Error: Sign in again before running the agent.", authError);
          resolve(null);
        } else {
          resolve(token);
        }
      });
    });
  });
}

function createChat(title = "New conversation", messages = []) {
  return {
    id: crypto.randomUUID(),
    title,
    messages,
    updatedAt: new Date().toISOString()
  };
}

function activeChat() {
  return chats.find(chat => chat.id === activeChatId);
}

function persistChats() {
  chrome.storage.local.set({ chats, activeChatId });
}

function renderChatList() {
  chatList.innerHTML = "";
  chats
    .slice()
    .sort((first, second) => new Date(second.updatedAt) - new Date(first.updatedAt))
    .forEach(chat => {
      const button = document.createElement("button");
      button.className = `chat-list-item${chat.id === activeChatId ? " active" : ""}`;
      button.type = "button";
      button.title = chat.title;
      button.innerHTML = `<strong>${chat.title}</strong><span>${chat.messages.length} message${chat.messages.length === 1 ? "" : "s"}</span>`;
      button.addEventListener("click", () => switchChat(chat.id));
      chatList.appendChild(button);
    });
}

function renderMessage(text, sender = "system") {
  const senderNames = { user: "You", agent: "Agent", system: "System" };
  const msgDiv = document.createElement("div");
  msgDiv.classList.add("message-bubble", `sender-${sender}`);

  const senderTag = document.createElement("div");
  senderTag.className = "sender-tag";
  senderTag.textContent = senderNames[sender] || "System";
  const messageText = document.createElement("div");
  messageText.className = "message-text";
  messageText.textContent = text;
  msgDiv.append(senderTag, messageText);
  chatContainer.appendChild(msgDiv);
}

function renderActiveChat() {
  const chat = activeChat();
  chatContainer.innerHTML = "";
  chatTitle.textContent = chat ? chat.title : "New conversation";
  if (chat) chat.messages.forEach(message => renderMessage(message.text, message.sender));
  chatContainer.scrollTop = chatContainer.scrollHeight;
  renderChatList();
}

function switchChat(chatId) {
  if (!chats.some(chat => chat.id === chatId)) return;
  activeChatId = chatId;
  continueCurrentChat = true;
  persistChats();
  renderActiveChat();
  objectiveInput.focus();
}

function startNewChat() {
  const chat = createChat();
  chats.push(chat);
  activeChatId = chat.id;
  continueCurrentChat = true;
  persistChats();
  renderActiveChat();
  objectiveInput.focus();
}

// Load existing user session and migrate the previous flat history into one chat.
chrome.storage.local.get(["googleUser", "chatHistory", "chats", "activeChatId"], (data) => {
  if (data.googleUser) {
    updateUserUI(data.googleUser);
  }
  if (Array.isArray(data.chats) && data.chats.length) {
    chats = data.chats;
    activeChatId = data.activeChatId || chats[0].id;
  } else {
    const legacyMessages = Array.isArray(data.chatHistory) ? data.chatHistory : [];
    const migratedChat = createChat(legacyMessages[0]?.text?.slice(0, 42) || "New conversation", legacyMessages);
    chats = [migratedChat];
    activeChatId = migratedChat.id;
    persistChats();
  }
  renderActiveChat();
});

newChatButton.addEventListener("click", startNewChat);
toggleSidebarButton.addEventListener("click", () => {
  const collapsed = !document.querySelector(".app-shell").classList.contains("sidebar-collapsed");
  setSidebarCollapsed(collapsed);
  chrome.storage.local.set({ sidebarCollapsed: collapsed });
});
continueChatButton.addEventListener("click", () => {
  continueCurrentChat = true;
  objectiveInput.focus();
});


// Google Sign-In / Sign-Out Handler
authButton.addEventListener("click", () => {
  if (currentUser) {
    // Sign Out
    chrome.identity.clearAllCachedAuthTokens(() => {
      currentUser = null;
      googleAccessToken = null;
      chrome.storage.local.remove("googleUser");
      updateUserUI(null);
    });
  } else {
    // Sign In via Chrome Identity API
    requestFreshGoogleAccessToken().then((token) => {
      const authError = chrome.runtime.lastError;
      if (authError || !token) {
        const errorMessage = authError?.message || "No token received and no specific error message.";
        if (errorMessage.includes("bad client id")) {
          console.error(
            "Authentication Error: The OAuth client ID is not registered for this extension. " +
            "Create a Chrome App OAuth client for extension ID " + chrome.runtime.id +
            " and update oauth2.client_id in manifest.json.",
            authError
          );
        } else {
          console.error("Authentication Error:", errorMessage);
        }
        return;
      }

      googleAccessToken = token;

      // Fetch Profile Data using token
      fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(res => res.json())
      .then(profile => {
        currentUser = profile;
        chrome.storage.local.set({ googleUser: profile });
        updateUserUI(profile);
      })
      .catch(err => console.error("Profile Fetch Error:", err));
    });
  }
});

function updateUserUI(user) {
  currentUser = user;
  if (user) {
    userName.textContent = user.name || user.email;
    if (user.picture) {
      userAvatar.src = user.picture;
      userAvatar.style.display = "block";
    }
    authButton.textContent = "Sign Out";
    authButton.style.backgroundColor = "#ef4444";
  } else {
    userName.textContent = "Not signed in";
    userAvatar.style.display = "none";
    authButton.textContent = "Sign In";
    authButton.style.backgroundColor = "#4f74d9";
  }
}

// Append a message to the active chat and persist the complete transcript.
function addMessage(text, sender = "system") {
  const chat = activeChat();
  if (!chat) return;
  const message = { sender, text, timestamp: new Date().toISOString() };
  chat.messages.push(message);
  chat.updatedAt = message.timestamp;
  if (sender === "user" && chat.title === "New conversation") {
    chat.title = text.slice(0, 42) || "New conversation";
  }
  renderMessage(text, sender);
  chatContainer.scrollTop = chatContainer.scrollHeight;
  persistChats();
  renderChatList();
}

// Keep track of the step count locally
let currentStep = 0;
const maxSteps = 15;

function setAgentState(isRunning) {
  if (isRunning) {
    agentStateContainer.style.display = 'block';
    idleStateContainer.style.display = 'none';
    stopButton.style.display = 'inline-block';
  } else {
    agentStateContainer.style.display = 'none';
    idleStateContainer.style.display = 'flex';
    stopButton.style.display = 'none';
    startButton.disabled = false;
    objectiveInput.disabled = false;
  }
}
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "agent_log") {
    const logText = message.text;

    // 1. Update the Header Status inside the dropdown
    const stepMatch = logText.match(/Step (\d+) of (\d+)/);
    const statusText = document.getElementById("logs-status-text");
    const agentStatusText = document.getElementById("agent-status-text");
    const indicator = document.querySelector(".status-indicator");

    if (stepMatch) {
      currentStep = parseInt(stepMatch[1]);
      if (statusText) statusText.innerText = `Working, ${currentStep}/${maxSteps}`;
      if (indicator) {
        indicator.classList.add("active");
        indicator.classList.remove("finished");
      }
      if (agentStatusText) agentStatusText.innerText = `Working... (Step ${currentStep}/${maxSteps})`;
    } else if (logText.includes("🤖 Screenshot captured")) {
      if (statusText) statusText.innerText = `Analyzing screenshot (Step ${currentStep})...`;
      if (agentStatusText) agentStatusText.innerText = `Analyzing... (Step ${currentStep})`;
    }

    // 2. Insert the raw logs STRICTLY inside the dropdown content container
    const logPanel = document.getElementById("log-panel");
    if (logPanel) {
      let icon = '➡️';
      if (logText.toLowerCase().includes('click')) icon = '🖱️';
      if (logText.toLowerCase().includes('type')) icon = '⌨️';
      if (logText.toLowerCase().includes('scroll')) icon = '↕️';
      if (logText.toLowerCase().includes('navigating')) icon = '🌐';
      if (logText.toLowerCase().includes('analyzing')) icon = '🧠';
      if (logText.toLowerCase().includes('error') || logText.toLowerCase().includes('failed')) icon = '❌';
      if (logText.toLowerCase().includes('stop')) icon = '🛑';

      const logLine = document.createElement("div");
      logLine.className = "log-line";
      logLine.style.borderBottom = "1px solid rgba(255,255,255,0.03)";
      logLine.innerHTML = `<span style="margin-right: 8px;">${icon}</span> ${logText}`;
      
      logPanel.appendChild(logLine);
      logPanel.scrollTop = logPanel.scrollHeight; // Auto-scroll inside the details box
    }
  }

  // Handle when the agent finishes
  if (message.action === "agent_finished") {
    const statusText = document.getElementById("logs-status-text");
    const agentStatusText = document.getElementById("agent-status-text");
    const indicator = document.querySelector(".status-indicator");
    
    if (statusText) statusText.innerText = `Completed successfully!`;
    if (agentStatusText) agentStatusText.innerText = `Finished!`;
    if (indicator) {
      indicator.classList.remove("active");
      indicator.classList.add("finished");
    }
    setAgentState(false);
  }
  if (message.action === "agent_achievement") {
    addMessage(message.text, "agent");
  }
});

// Send the objective to the agent on click
startButton.addEventListener("click", async () => {
  const objective = objectiveInput.value.trim();
  if (!objective) return;

  if (!googleAccessToken) {
    googleAccessToken = await requestFreshGoogleAccessToken();
    if (!googleAccessToken) return;
  }

  if (!continueCurrentChat && activeChat().messages.length > 0) {
    startNewChat();
  }

  setAgentState(true); // Switch to "running" view

  // Render & save user message
  addMessage(objective, "user");

  objectiveInput.value = "";
  objectiveInput.style.height = "40px"; // Reset height
  
  addMessage("⚡ Initializing agent loop...", "system");

  // Broadcast to background.js to kick off the loop
  chrome.runtime.sendMessage({
    action: "start_agent_with_objective",
    objective: objective,
    accessToken: googleAccessToken,
    chatContext: activeChat().messages
  });
  continueCurrentChat = true;
});

// Auto-resize textarea height based on content
objectiveInput.addEventListener("input", function() {
  this.style.height = "auto";
  this.style.height = this.scrollHeight + "px";
});

// Support CMD/Ctrl + Enter to send and reset height
// Speech Recognition Engine
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = "en-US";

  let isListening = false;

  micButton.addEventListener("click", () => {
    if (!isListening) {
      recognition.start();
    } else {
      recognition.stop();
    }
  });

  recognition.onstart = () => {
    isListening = true;
    micButton.textContent = "■"; // Stop square
    micButton.style.backgroundColor = "#ef4444";
    objectiveInput.placeholder = "Listening...";
  };

  recognition.onend = () => {
    isListening = false;
    micButton.textContent = "🎙️"; // This one is generally well-supported, but could be "Mic"
    micButton.style.backgroundColor = "#161618";
    objectiveInput.placeholder = "Ask the agent to do something...";
  };

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    objectiveInput.value = objectiveInput.value ? objectiveInput.value + " " + transcript : transcript;
    
    // Automatically trigger the height recalculation for the new voice text
    objectiveInput.dispatchEvent(new Event("input"));
  };

  recognition.onerror = (event) => {
    console.error("Speech recognition error:", event.error);
    if (event.error === "not-allowed") {
      chrome.tabs.create({
        url: chrome.runtime.getURL("popup.html?requestMic=true")
      });
    }
  };

// Check if this page was opened as the temporary permission tab
if (window.location.search.includes("requestMic=true")) {
  // Overwrite the body instantly to show a clean permission prompt screen
  document.body.innerHTML = `
    <div style="background:#121214; color:#e4e4e7; font-family:sans-serif; text-align:center; height:100vh; display:flex; flex-direction:column; justify-content:center; align-items:center; margin:0;">
      <h2>Microphone Access Required</h2>
      <p>Please click 'Allow' when prompted to enable voice input for your agent.</p>
    </div>
  `;
  
  navigator.mediaDevices.getUserMedia({ audio: true })
    .then((stream) => {
      // Stop the tracks immediately since we just needed the permission grant
      stream.getTracks().forEach(track => track.stop());
      window.close();
    })
    .catch((err) => {
      console.error("Permission page error:", err);
    });
}
} else {
  micButton.style.display = "none"; // Fallback safety if API isn't supported
}

stopButton.addEventListener("click", () => {
  chrome.runtime.sendMessage({ action: "stop_agent" });
  setAgentState(false);
});