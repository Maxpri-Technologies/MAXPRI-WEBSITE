# Voyager Agentic Browser

Voyager Agentic Browser is a Chrome/Edge browser extension that turns the browser into an autonomous task assistant. It can inspect page content, reason about the next best action, automate clicks and text entry, and work with Google services such as Gmail, Google Calendar, and Google Drive.

The extension includes a side panel chat UI, persistent memory, task tracking, and Google sign-in to support real workflow automation without leaving the browser.

## Features

- Autonomous browser task execution using a browser-side agent loop, including batched dependent actions such as clicking a search box, typing, and submitting before re-analyzing the page
- Object-finding workflows that select matching products and add them to the cart, or select and verify a flight before final booking
- Side panel interface for chat and task management
- Switchable Agent mode for browser tasks and Code mode for editing files in the selected local folder
- Google account integration for Gmail, Calendar, and Drive access
- Optional access to one user-selected local folder for listing, reading, and editing text files
- User memory and chat context persistence
- Account-scoped agent personalization for tone, response detail, autonomy, and custom preference context
- Task board for live progress tracking
- Support for common browser actions like navigation, search, click, type, scroll, and hover
- Extension workflow designed for direct Google Workspace operations instead of web navigation when relevant

## Project structure

```text
.
├── favicons/
├── memory/
│   └── knowledge-base.js
├── script/
│   ├── background.js
│   ├── content.js
│   ├── popup.js
│   └── sign-in-button.js
├── .gitignore
├── index.html
├── logo.png
├── manifest.json
├── popup.css
├── wrangler.jsonc
└── README.md
```

## Main files

- `manifest.json` — Chrome extension manifest with background service worker and side panel configuration
- `index.html` — extension UI shell and chat panel layout
- `script/background.js` — core agent logic, Google API handling, task board, and browser automation loop
- `script/content.js` — DOM interaction logic used to read page elements and execute actions on the active page
- `script/popup.js` — frontend behavior for the UI and chat interactions
- `memory/knowledge-base.js` — static knowledge and task-aware context used by the agent

## How it works

Voyager uses a service worker background script to:

- monitor the active browser tab
- capture page state and screenshots
- identify interactive elements on the page
- decide the next action using AI-generated planning
- execute browser interactions or direct Google Workspace operations
- maintain memory and progress tracking across steps

## Getting started

### Prerequisites

- Google Chrome or Microsoft Edge
- Developer mode enabled for extensions
- A Google account connected to the browser for optional Gmail/Drive/Calendar access

### Load the extension locally

1. Open Chrome and navigate to `chrome://extensions` (or `edge://extensions`).
2. Enable Developer mode.
3. Click Load unpacked.
4. Select this repository folder.
5. The extension should appear in your browser toolbar.

## Usage

1. Open the Voyager extension from the toolbar.
2. Sign in with your Google account if prompted.
3. Enter a task such as:
   - "Find and select a flight to Orlando, Florida on Expedia"
   - "Find a laptop on Amazon"
   - "Create a meeting notes document template"
   - "Read my local workspace notes and update the summary"
   - Switch to **Code** mode to request code changes in the selected local folder; use **Agent** mode for browser tasks
   - "Draft an email to alice@example.com"
4. Voyager will show progress in the live task board. Agent mode works in the active browser tab; Code mode works in the connected folder.
5. To sign out, open your profile menu and choose **Sign out**. This clears Voyager's saved sign-in and cached Google tokens without deleting your saved chats or settings; use **Delete account** only if you intend to erase local Voyager data.

## Local workspace folder

Choose a folder from the **+** menu beside the microphone to grant access to that folder only. Voyager can list its entries and read or write supported text files (up to 50 KB); file paths are relative to the selected folder. The browser remembers the folder handle locally, and access can be reconnected or disconnected from the **+** menu. No additional extension-wide filesystem permission is requested.

In Code mode, Voyager first inventories the selected folder structure (up to 40 folders and 1,200 entries), then reads up to 10 likely project text files before planning and can read up to 20 files total as needed. Common generated and dependency folders such as `node_modules`, `dist`, and `.git` are skipped. Requests to revise clothing/product names or explicit requests to work in source code automatically switch to Code mode. Every file creation or replacement pauses for a review dialog showing the exact path and proposed content. Voyager does not delete files. Files it reads are sent to the AI service used to complete the task, so only select a folder and ask it to read material you are comfortable sharing. Use a current version of Chrome or Edge with the File System Access API.

## Google integrations

This project is designed to work with Google services directly via OAuth and Google APIs, including:

- Gmail inbox reads and draft creation
- Google Calendar event listing and creation
- Google Drive file and folder management
- Google Docs creation and content generation

Permissions are declared in the extension manifest and require a signed-in Google account for these workflows.

## Agent personalization

Open **Settings** from the profile menu to set the agent's display name, communication tone, response detail and format, autonomy and confirmation preference, and optional extra preferences. The existing welcome message and greeting-name options remain available. Settings are stored locally under the active account's preference key (with a guest profile fallback) and older saved settings load with safe defaults. Personalization guides the agent's system instruction as preference context; it cannot override higher-priority instructions or confirmations for sensitive actions.

## Notes

- The project is primarily frontend/browser automation code written in JavaScript and HTML/CSS.
- It does not appear to include a package.json or a traditional build pipeline; it is meant to be loaded as an unpacked browser extension.
- Some workflows require the user to sign in and allow the Google OAuth scopes configured in the extension manifest.

## License

No explicit license file was found in the repository root, so licensing terms should be confirmed before redistribution or reuse.

## Contributing

If you want to extend the project:

- keep the background automation logic in `script/background.js`
- add UI updates in `index.html` and `popup.css`
- use `script/content.js` for page-level DOM interaction logic
- keep Google API and browser automation behaviors isolated and testable

## Summary

Voyager Agentic Browser is a browser-based AI assistant that helps users automate tasks in the browser and interact with Google Workspace directly. It is a practical agentic extension for browsing, research, scheduling, email drafting, and document management from within the browser UI.

---

Built for autonomous browser workflows and Google Workspace integration.
