const chatContainer = document.getElementById("chatContainer");
const objectiveInput = document.getElementById("objectiveInput");
const startButton = document.getElementById("startButton");
const stopButton = document.getElementById("stop-btn");
const micButton = document.getElementById("micButton");
const emptyChatState = document.getElementById("emptyChatState");
const authCardScreen = document.getElementById("authCardScreen");
const authCardSignIn = document.getElementById("authCardSignIn");
const profileButton = document.getElementById("profileButton");
const sidebarUserAvatar = document.getElementById("sidebarUserAvatar");
const profileMenu = document.getElementById("profileMenu");
const profileMenuName = document.getElementById("profileMenuName");
const settingsButton = document.getElementById("settingsButton");
const signOutButton = document.getElementById("signOutButton");
const deleteAccountButton = document.getElementById("deleteAccountButton");
const settingsOverlay = document.getElementById("settingsOverlay");
const closeSettingsButton = document.getElementById("closeSettingsButton");
const cancelSettingsButton = document.getElementById("cancelSettingsButton");
const personalizationForm = document.getElementById("personalizationForm");
const agentDisplayNameInput = document.getElementById("agentDisplayNameInput");
const communicationToneInput = document.getElementById("communicationToneInput");
const responseDetailInput = document.getElementById("responseDetailInput");
const responseFormatInput = document.getElementById("responseFormatInput");
const autonomyPreferenceInput = document.getElementById("autonomyPreferenceInput");
const customInstructionsInput = document.getElementById("customInstructionsInput");
const welcomeMessageInput = document.getElementById("welcomeMessageInput");
const preferredNameInput = document.getElementById("preferredNameInput");
const useNameInGreeting = document.getElementById("useNameInGreeting");
const welcomeMessagePreview = document.getElementById("welcomeMessagePreview");
const settingsStatus = document.getElementById("settingsStatus");
const homeButton = document.getElementById("homeButton");
const homeDashboard = document.getElementById("homeDashboard");
const homeRefreshButton = document.getElementById("homeRefreshButton");
const unreadEmailCount = document.getElementById("unreadEmailCount");
const unreadEmailStatus = document.getElementById("unreadEmailStatus");
const recentEmailsContainer = document.getElementById("recentEmails");
const thisWeekEventsContainer = document.getElementById("thisWeekEvents");
const thisWeekEventCount = document.getElementById("thisWeekEventCount");
const nextWeekEventsContainer = document.getElementById("nextWeekEvents");
const nextWeekEventCount = document.getElementById("nextWeekEventCount");
const agentStateContainer = document.getElementById("agent-state-container");
const idleStateContainer = document.getElementById("idle-state-container");
const chatList = document.getElementById("chatList");
const newChatButton = document.getElementById("newChatButton");
const toggleSidebarButton = document.getElementById("toggleSidebarButton");
const continueChatButton = document.getElementById("continueChatButton");
const chatTitle = document.getElementById("chatTitle");
const agentTaskBoard = document.getElementById("agentTaskBoard");
const agentTaskList = document.getElementById("agentTaskList");
const agentTaskSummary = document.getElementById("agentTaskSummary");
const driveFolderNameInput = document.getElementById("driveFolderNameInput");
const driveFileNameInput = document.getElementById("driveFileNameInput");
const driveFileContentInput = document.getElementById("driveFileContentInput");
const driveCreateFolderButton = document.getElementById("driveCreateFolderButton");
const driveCreateFileButton = document.getElementById("driveCreateFileButton");
const driveListFilesButton = document.getElementById("driveListFilesButton");
const driveStatus = document.getElementById("driveStatus");
const workspaceFolderName = document.getElementById("workspaceFolderName");
const workspaceStatus = document.getElementById("workspaceStatus");
const workspaceMenuButton = document.getElementById("workspaceMenuButton");
const workspaceMenu = document.getElementById("workspaceMenu");
const chooseWorkspaceButton = document.getElementById("chooseWorkspaceButton");
const reconnectWorkspaceButton = document.getElementById("reconnectWorkspaceButton");
const removeWorkspaceButton = document.getElementById("removeWorkspaceButton");
const agentModeButton = document.getElementById("agentModeButton");
const codeModeButton = document.getElementById("codeModeButton");
const workspaceWriteOverlay = document.getElementById("workspaceWriteOverlay");
const workspaceWritePath = document.getElementById("workspaceWritePath");
const workspacePreviousContentSection = document.getElementById("workspacePreviousContentSection");
const workspacePreviousContent = document.getElementById("workspacePreviousContent");
const workspaceProposedContent = document.getElementById("workspaceProposedContent");
const workspaceWriteStatus = document.getElementById("workspaceWriteStatus");
const cancelWorkspaceWriteButton = document.getElementById("cancelWorkspaceWriteButton");
const approveWorkspaceWriteButton = document.getElementById("approveWorkspaceWriteButton");
const walkthroughOverlay = document.getElementById("walkthroughOverlay");
const walkthroughContent = document.getElementById("walkthroughContent");
const walkthroughStepLabel = document.getElementById("walkthroughStepLabel");
const walkthroughBackButton = document.getElementById("walkthroughBackButton");
const walkthroughNextButton = document.getElementById("walkthroughNextButton");
const walkthroughSkipButton = document.getElementById("walkthroughSkipButton");

let currentUser = null;
let googleAccessToken = null;
let chats = [];
let activeChatId = null;
let continueCurrentChat = true;
let workspaceDirectoryHandle = null;
let pendingWorkspaceWriteDecision = null;
let workspaceDatabasePromise = null;
let selectedMode = "agent";
let walkthroughStep = 0;
let activeAgentLogChatId = null;
let activeAgentLogMessageId = null;
const agentLogsByMessageId = new Map();
const DEFAULT_WELCOME_MESSAGE = "Let's take it from here.";
const DEFAULT_PERSONALIZATION_PREFERENCES = {
  agentDisplayName: "Voyager",
  communicationTone: "friendly",
  responseDetail: "balanced",
  responseFormat: "automatic",
  autonomyPreference: "balanced",
  customInstructions: "",
  message: DEFAULT_WELCOME_MESSAGE,
  preferredName: "",
  useName: false
};
const PERSONALIZATION_OPTIONS = {
  communicationTone: ["friendly", "concise", "professional", "supportive"],
  responseDetail: ["concise", "balanced", "detailed"],
  responseFormat: ["automatic", "bullets", "steps"],
  autonomyPreference: ["cautious", "balanced", "proactive"]
};
let welcomePreferences = { ...DEFAULT_PERSONALIZATION_PREFERENCES };

const WALKTHROUGH_STEPS = [
  {
    title: "Choose a mode and describe your task",
    body: "Use Agent mode for browser tasks, or Code mode to edit files in a folder you connect. Then describe what you need in plain language.",
    icon: "*"
  },
  {
    title: "Voyager works in the right place",
    body: "Agent mode works in your active browser tab. Code mode works only in the local folder you choose.",
    icon: ">"
  },
  {
    title: "You stay in control",
    body: "Voyager pauses when your confirmation is needed. Review important actions before anything is submitted.",
    icon: "OK"
  },
  {
    title: "Your chats stay with you",
    body: "Your conversations are saved to your Google account. Use the sidebar to return to an earlier task or start fresh.",
    icon: "[]"
  }
];

function walkthroughStorageKey(user) {
  const accountId = (user?.id || user?.email || "guest").toString().trim();
  return `voyager_walkthrough_completed_${accountId}`;
}

function renderWalkthroughStep() {
  const step = WALKTHROUGH_STEPS[walkthroughStep];
  if (!step || !walkthroughContent) return;

  walkthroughContent.innerHTML = `
    <div class="walkthrough-icon" aria-hidden="true">${step.icon}</div>
    <h2 id="walkthroughTitle">${step.title}</h2>
    <p>${step.body}</p>
  `;
  walkthroughStepLabel.textContent = `${walkthroughStep + 1} of ${WALKTHROUGH_STEPS.length}`;
  walkthroughBackButton.hidden = walkthroughStep === 0;
  walkthroughNextButton.textContent = walkthroughStep === WALKTHROUGH_STEPS.length - 1 ? "Get started" : "Next";
  document.querySelectorAll(".walkthrough-dot").forEach((dot, index) => {
    dot.classList.toggle("active", index === walkthroughStep);
    dot.classList.toggle("complete", index < walkthroughStep);
  });
}

function finishWalkthrough() {
  if (!currentUser) return;
  chrome.storage.local.set({ [walkthroughStorageKey(currentUser)]: true });
  walkthroughOverlay.hidden = true;
  document.body.classList.remove("walkthrough-open");
}

function showWalkthroughIfNeeded(user) {
  const storageKey = walkthroughStorageKey(user);
  chrome.storage.local.get(storageKey, (data) => {
    if (data[storageKey] === true) return;
    walkthroughStep = 0;
    renderWalkthroughStep();
    walkthroughOverlay.hidden = false;
    document.body.classList.add("walkthrough-open");
  });
}

function hideTaskBoard() {
  agentTaskList.replaceChildren();
  agentTaskBoard.hidden = true;
  agentTaskSummary.textContent = "";
}

function renderAgentTaskList(tasks) {
  const taskItems = Array.isArray(tasks) ? tasks : [];
  agentTaskList.replaceChildren();
  agentTaskBoard.hidden = taskItems.length === 0;
  if (!taskItems.length) return;

  const completedCount = taskItems.filter((task) => task.status === "completed").length;
  agentTaskSummary.textContent = `${completedCount}/${taskItems.length} complete`;

  taskItems.forEach((task) => {
    const item = document.createElement("li");
    const status = ["planned", "in_progress", "completed", "blocked"].includes(task.status)
      ? task.status
      : "planned";
    item.className = `agent-task agent-task-${status}`;

    const marker = document.createElement("span");
    marker.className = "agent-task-marker";
    marker.setAttribute("aria-hidden", "true");
    marker.textContent = status === "completed" ? "✓" : status === "blocked" ? "!" : status === "in_progress" ? "•" : "○";

    const label = document.createElement("span");
    label.textContent = task.title;
    item.append(marker, label);
    agentTaskList.appendChild(item);
  });
}

function createInitialTaskBoard(objective) {
  if (typeof getVoyagerTaskPlan === "function") return getVoyagerTaskPlan(objective);
  return [{ id: "complete", title: "Complete the requested task", status: "in_progress" }];
}

const compactPanelQuery = window.matchMedia("(max-width: 420px)");

chrome.storage.local.get(["sidebarCollapsed"], (data) => {
  setSidebarCollapsed(data.sidebarCollapsed === true || compactPanelQuery.matches);
});

compactPanelQuery.addEventListener("change", (event) => {
  if (event.matches) setSidebarCollapsed(true);
});

const CHEVRON_LEFT_SVG = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"/></svg>`;
const CHEVRON_RIGHT_SVG = `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>`;

function setSidebarCollapsed(collapsed) {
  document.querySelector(".app-shell").classList.toggle("sidebar-collapsed", collapsed);
  toggleSidebarButton.innerHTML = collapsed ? CHEVRON_RIGHT_SVG : CHEVRON_LEFT_SVG;
  toggleSidebarButton.title = collapsed ? "Expand chats" : "Collapse chats";
  toggleSidebarButton.setAttribute("aria-label", toggleSidebarButton.title);
}

const GOOGLE_AUTH_SCOPES = [
  "https://www.googleapis.com/auth/userinfo.profile",
  "https://www.googleapis.com/auth/userinfo.email",
  "https://www.googleapis.com/auth/cloud-platform",
  "https://www.googleapis.com/auth/generative-language.retriever",
  "https://www.googleapis.com/auth/documents",
  "https://www.googleapis.com/auth/drive",
  "https://www.googleapis.com/auth/drive.file",
  "https://www.googleapis.com/auth/gmail.readonly",
  "https://www.googleapis.com/auth/gmail.compose",
  "https://www.googleapis.com/auth/gmail.modify",
  "https://www.googleapis.com/auth/calendar",
  "https://www.googleapis.com/auth/calendar.events"
];

function requestFreshGoogleAccessToken() {
  return new Promise((resolve) => {
    chrome.identity.clearAllCachedAuthTokens(() => {
      chrome.identity.getAuthToken({ interactive: true, scopes: GOOGLE_AUTH_SCOPES }, (token) => {
        const authError = chrome.runtime.lastError;
        if (authError || !token) {
          console.error("Authentication Error: Sign in again before running the agent.", authError);
          resolve(null);
        } else {
          resolve(token);
        }
      });
    });
  });
}

function createChat(title = "New conversation", messages = []) {
  return {
    id: crypto.randomUUID(),
    title,
    messages,
    updatedAt: new Date().toISOString()
  };
}

function getChatsStorageKey(user = currentUser) {
  if (user && (user.id || user.email)) {
    const accountId = (user.id || user.email || "guest").toString().trim();
    return `voyager_chats_${accountId}`;
  }
  return "voyager_chats_guest";
}

function loadChatsForUser(user) {
  return new Promise((resolve, reject) => {
    const accountKey = getChatsStorageKey(user);
    chrome.storage.local.get([accountKey, "activeChatId"], (data) => {
      const storageError = chrome.runtime.lastError;
      if (storageError) {
        reject(new Error(storageError.message));
        return;
      }
      chats = Array.isArray(data[accountKey]) ? data[accountKey] : [];
      if (!chats.length) chats = [createChat()];
      activeChatId = chats.some((chat) => chat.id === data.activeChatId)
        ? data.activeChatId
        : chats[0].id;
      continueCurrentChat = true;
      persistChats();
      renderActiveChat();
      resolve();
    });
  });
}

function getWelcomePreferencesStorageKey(user = currentUser) {
  const accountId = (user?.id || user?.email || "guest").toString().trim();
  return `voyager_preferences_${accountId}`;
}

function normalizePersonalizationPreferences(stored = {}) {
  const normalized = { ...DEFAULT_PERSONALIZATION_PREFERENCES };
  normalized.agentDisplayName = typeof stored.agentDisplayName === "string"
    ? stored.agentDisplayName.trim().slice(0, 60) || normalized.agentDisplayName
    : normalized.agentDisplayName;
  for (const field of Object.keys(PERSONALIZATION_OPTIONS)) {
    if (PERSONALIZATION_OPTIONS[field].includes(stored[field])) normalized[field] = stored[field];
  }
  normalized.customInstructions = typeof stored.customInstructions === "string"
    ? stored.customInstructions.trim().slice(0, 1500)
    : normalized.customInstructions;
  normalized.message = typeof stored.message === "string"
    ? stored.message.trim().slice(0, 120) || DEFAULT_WELCOME_MESSAGE
    : DEFAULT_WELCOME_MESSAGE;
  normalized.preferredName = typeof stored.preferredName === "string"
    ? stored.preferredName.trim().slice(0, 60)
    : "";
  normalized.useName = stored.useName === true;
  return normalized;
}

function formatWelcomeMessage(preferences) {
  const template = preferences.message.trim() || DEFAULT_WELCOME_MESSAGE;
  const name = (preferences.preferredName || currentUser?.name || "").trim();
  if (!preferences.useName || !name) return template.replace(/\s*\{name\}/gi, "").trim();
  if (/\{name\}/i.test(template)) return template.replace(/\{name\}/gi, name);
  return `${template.replace(/[.!?]+$/, "")}, ${name}.`;
}

function getWelcomeMessage() {
  return formatWelcomeMessage(welcomePreferences);
}

function renderWelcomeMessage() {
  const welcomeTitle = emptyChatState.querySelector(".empty-title");
  if (welcomeTitle) welcomeTitle.textContent = getWelcomeMessage();
}

function updateWelcomePreview() {
  const previewPreferences = {
    message: welcomeMessageInput.value,
    preferredName: preferredNameInput.value,
    useName: useNameInGreeting.checked
  };
  welcomeMessagePreview.textContent = formatWelcomeMessage(previewPreferences);
}

function loadWelcomePreferences(user = currentUser, onLoaded) {
  const storageKey = getWelcomePreferencesStorageKey(user);
  chrome.storage.local.get(storageKey, (data) => {
    const storageError = chrome.runtime.lastError;
    if (storageError) {
      console.error("Could not load personalization settings:", storageError);
      settingsStatus.textContent = "Could not load your personalization settings.";
      return;
    }
    if (storageKey !== getWelcomePreferencesStorageKey(currentUser)) return;

    welcomePreferences = normalizePersonalizationPreferences(data[storageKey] || {});
    renderWelcomeMessage();
    if (onLoaded) onLoaded();
  });
}

function populateSettingsForm() {
  agentDisplayNameInput.value = welcomePreferences.agentDisplayName;
  communicationToneInput.value = welcomePreferences.communicationTone;
  responseDetailInput.value = welcomePreferences.responseDetail;
  responseFormatInput.value = welcomePreferences.responseFormat;
  autonomyPreferenceInput.value = welcomePreferences.autonomyPreference;
  customInstructionsInput.value = welcomePreferences.customInstructions;
  welcomeMessageInput.value = welcomePreferences.message;
  preferredNameInput.value = welcomePreferences.preferredName || currentUser?.name || "";
  useNameInGreeting.checked = welcomePreferences.useName;
  settingsStatus.textContent = "";
  updateWelcomePreview();
}

function openSettings() {
  profileMenu.hidden = true;
  profileButton.setAttribute("aria-expanded", "false");
  settingsStatus.textContent = "Loading your settings...";
  settingsOverlay.hidden = false;
  document.body.classList.add("settings-open");
  loadWelcomePreferences(currentUser, () => {
    if (settingsOverlay.hidden) return;
    populateSettingsForm();
    agentDisplayNameInput.focus();
  });
}

function closeSettings() {
  const wasOpen = !settingsOverlay.hidden;
  settingsOverlay.hidden = true;
  document.body.classList.remove("settings-open");
  if (wasOpen && !document.body.classList.contains("signed-out")) profileButton.focus();
}

function activeChat() {
  return chats.find(chat => chat.id === activeChatId);
}

function persistChats() {
  const storageKey = getChatsStorageKey();
  chrome.storage.local.set({ [storageKey]: chats, activeChatId });
}

function renderChatList() {
  chatList.innerHTML = "";
  chats
    .slice()
    .sort((first, second) => new Date(second.updatedAt) - new Date(first.updatedAt))
    .forEach(chat => {
      const item = document.createElement("div");
      item.className = "chat-list-item-wrap";

      const button = document.createElement("button");
      button.className = `chat-list-item${chat.id === activeChatId ? " active" : ""}`;
      button.type = "button";
      button.title = chat.title;
      button.innerHTML = `<strong>${chat.title}</strong><span>${chat.messages.length} message${chat.messages.length === 1 ? "" : "s"}</span>`;
      button.addEventListener("click", () => switchChat(chat.id));

      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "chat-delete-button";
      deleteButton.title = `Delete chat: ${chat.title}`;
      deleteButton.setAttribute("aria-label", `Delete chat: ${chat.title}`);
      deleteButton.innerHTML = `
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
          <path d="M3 6h18"/>
          <path d="M8 6V4h8v2"/>
          <path d="M19 6l-1 14H6L5 6"/>
          <path d="M10 11v6"/>
          <path d="M14 11v6"/>
        </svg>
      `;
      deleteButton.addEventListener("click", (event) => {
        event.stopPropagation();
        deleteChat(chat.id);
      });

      item.appendChild(button);
      item.appendChild(deleteButton);
      chatList.appendChild(item);
    });
}

function renderMessage(text, sender = "system", message = {}) {
  const senderNames = { user: "You", agent: "Agent", system: "System" };
  const msgDiv = document.createElement("div");
  msgDiv.classList.add("message-bubble", `sender-${sender}`);
  if (message.id) msgDiv.dataset.messageId = message.id;

  const senderTag = document.createElement("div");
  senderTag.className = "sender-tag";
  senderTag.textContent = senderNames[sender] || "System";
  const messageText = document.createElement("div");
  messageText.className = "message-text";
  messageText.textContent = text;
  msgDiv.append(senderTag, messageText);
  const agentLogs = message.id ? agentLogsByMessageId.get(message.id) : null;
  if (agentLogs?.length) {
    renderAgentMessageLogs(msgDiv, agentLogs);
  }
  chatContainer.appendChild(msgDiv);
  return msgDiv;
}

function renderActiveChat() {
  hideTaskBoard();
  const chat = activeChat();
  renderWelcomeMessage();
  chatContainer.innerHTML = "";
  chatTitle.textContent = chat ? chat.title : "New conversation";
  emptyChatState.hidden = Boolean(chat && chat.messages.length > 0);
  chatContainer.appendChild(emptyChatState);
  if (chat && chat.messages.length > 0) {
    chat.messages.forEach(message => renderMessage(message.text, message.sender, message));
  }
  chatContainer.scrollTop = chatContainer.scrollHeight;
  renderChatList();
  refreshChatInputPlaceholder();
}

function switchChat(chatId) {
  if (!chats.some(chat => chat.id === chatId)) return;
  showChatWorkspace();
  activeChatId = chatId;
  continueCurrentChat = true;
  persistChats();
  renderActiveChat();
  objectiveInput.focus();
}

function deleteChat(chatId) {
  const index = chats.findIndex(chat => chat.id === chatId);
  if (index === -1) return;

  chats[index].messages.forEach((message) => {
    if (message.id) agentLogsByMessageId.delete(message.id);
  });
  chats.splice(index, 1);
  if (activeChatId === chatId) {
    activeChatId = chats[0]?.id || null;
  }
  if (!activeChatId && chats.length === 0) {
    const newChat = createChat();
    chats.push(newChat);
    activeChatId = newChat.id;
  }

  persistChats();
  renderActiveChat();
  objectiveInput.focus();
}

function startNewChat() {
  showChatWorkspace();
  const chat = createChat();
  chats.push(chat);
  activeChatId = chat.id;
  continueCurrentChat = true;
  persistChats();
  renderActiveChat();
  objectiveInput.focus();
}

function shouldSkipGoogleLandingPageForObjective(objective) {
  const text = String(objective || "");

  const meetingCalendarSignal = /scedule|schedul|schedule|calendar|event|appointment|meeting|invite/i.test(text);
  const directGoogleApiIntent = /gmail|google\s+mail|mailbox|inbox|read\s+my\s+emails?|check\s+my\s+emails?|show\s+my\s+emails?|draft\s+(?:an\s+)?email|compose\s+email|write\s+email|send\s+(?:an\s+)?email|create\s+(?:a\s+)?draft|email\s+to\s+[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}|check\s+my\s+mail|show\s+my\s+mail|read\s+my\s+mail|email\s+inbox/i.test(text);
  const directGoogleWorkspaceIntent = /google\s+doc(?:ument)?s?|create\s+(?:a\s+)?doc(?:ument)?|google\s+drive|drive\s+folder|drive\s+file|create\s+(?:a\s+)?folder|list\s+my\s+drive/i.test(text);
  const localWorkspaceIntent = /(?:selected|workspace)\s+(?:local\s+)?(?:files?|folders?|directories|workspace)\b|(?:files?|folders?|directories|documents?)\s+(?:in|from|inside)\s+(?:my|the|this|that|selected|local)\s+(?:local\s+)?(?:folder|directory|workspace|desktop)\b|(?:read|edit|update|organize|list|create|write|summarize|open|find|rename|move)\b.{0,40}\b(?:my\s+)?(?:local|desktop)\s+(?:files?|folders?|directories|documents?|workspace)\b|local\s+workspace\b|files?\s+on\s+my\s+(?:computer|desktop)|my\s+desktop/i.test(text);

  return meetingCalendarSignal || directGoogleApiIntent || directGoogleWorkspaceIntent || localWorkspaceIntent;
}

async function navigateToGoogleForFirstMessageIfNeeded(objective = "") {
  if (shouldSkipGoogleLandingPageForObjective(objective)) return;

  const chat = activeChat();
  if (!chat || chat.messages.length > 0) return;

  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab) return;

  await chrome.tabs.update(tab.id, { url: "https://www.google.com" });
  await new Promise((resolve) => setTimeout(resolve, 1200));
}

// Load existing user session and migrate the previous flat history into one chat.
chrome.storage.local.get(["googleUser", "chatHistory", "chatHistoryGuest", "chats", "activeChatId", "agentTaskList", "voyagerMode"], (data) => {
  setSelectedMode(data.voyagerMode, false);
  const savedUser = data.googleUser || null;
  if (savedUser) {
    updateUserUI(savedUser);
  } else {
    updateUserUI(null);
  }

  const accountKey = getChatsStorageKey(savedUser || currentUser);
  chrome.storage.local.get([accountKey, "chats", "activeChatId"], (accountData) => {
    const storedForAccount = Array.isArray(accountData[accountKey]) ? accountData[accountKey] : [];
    const storedLegacy = Array.isArray(accountData.chats) ? accountData.chats : [];

    if (storedForAccount.length) {
      chats = storedForAccount;
      activeChatId = accountData.activeChatId || chats[0].id;
    } else if (storedLegacy.length) {
      chats = storedLegacy;
      activeChatId = accountData.activeChatId || chats[0].id;
      persistChats();
    } else {
      const legacyMessages = Array.isArray(data.chatHistory) ? data.chatHistory : [];
      const migratedChat = createChat(legacyMessages[0]?.text?.slice(0, 42) || "New conversation", legacyMessages);
      chats = [migratedChat];
      activeChatId = migratedChat.id;
      persistChats();
    }

    renderActiveChat();
    renderAgentTaskList(data.agentTaskList);
    chrome.runtime.sendMessage({ action: "get_agent_task_list" }, (response) => {
      if (!chrome.runtime.lastError) renderAgentTaskList(response?.tasks);
    });
  });
});

// Receive every task change, including updates made while this panel was not
// the active runtime-message receiver.
chrome.storage.onChanged.addListener((changes, areaName) => {
  if (areaName === "local" && changes.agentTaskList) {
    renderAgentTaskList(changes.agentTaskList.newValue);
  }
});

newChatButton.addEventListener("click", startNewChat);
toggleSidebarButton.addEventListener("click", () => {
  const collapsed = !document.querySelector(".app-shell").classList.contains("sidebar-collapsed");
  setSidebarCollapsed(collapsed);
  chrome.storage.local.set({ sidebarCollapsed: collapsed });
});
continueChatButton.addEventListener("click", () => {
  showChatWorkspace();
  continueCurrentChat = true;
  objectiveInput.focus();
});

function showChatWorkspace() {
  document.body.classList.remove("home-view-active");
  homeDashboard.hidden = true;
  homeButton.setAttribute("aria-pressed", "false");
}

function localDateKey(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, "0");
  const day = String(date.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
}

function eventOverlapsPeriod(event, periodStart, periodEnd) {
  const eventStart = /^\d{4}-\d{2}-\d{2}$/.test(event.start || "")
    ? new Date(`${event.start}T00:00:00`)
    : new Date(event.start);
  const eventEnd = /^\d{4}-\d{2}-\d{2}$/.test(event.end || "")
    ? new Date(`${event.end}T00:00:00`)
    : new Date(event.end || event.start);
  return eventStart < periodEnd && eventEnd > periodStart;
}

function getHomeWeekStart(date) {
  const weekStart = new Date(date);
  weekStart.setHours(0, 0, 0, 0);
  weekStart.setDate(weekStart.getDate() - ((weekStart.getDay() + 6) % 7));
  return weekStart;
}

function formatHomeEventDate(event) {
  const start = /^\d{4}-\d{2}-\d{2}$/.test(event.start || "")
    ? new Date(`${event.start}T00:00:00`)
    : new Date(event.start);
  if (Number.isNaN(start.getTime())) return "Date not set";
  return new Intl.DateTimeFormat(undefined, { weekday: "short", month: "short", day: "numeric" }).format(start);
}

function formatHomeEventTime(event) {
  if (/^\d{4}-\d{2}-\d{2}$/.test(event.start || "")) return "All day";
  const start = new Date(event.start);
  if (Number.isNaN(start.getTime())) return "Time not set";
  const formatTime = (date) => new Intl.DateTimeFormat(undefined, { hour: "numeric", minute: "2-digit" }).format(date);
  const end = event.end ? new Date(event.end) : null;
  return end && !Number.isNaN(end.getTime()) ? `${formatTime(start)} - ${formatTime(end)}` : formatTime(start);
}

function renderHomeEvents(container, countElement, events, periodStart, periodEnd, error) {
  container.replaceChildren();
  if (error) {
    countElement.textContent = "!";
    const message = document.createElement("p");
    message.className = "home-loading home-error";
    message.textContent = error;
    container.appendChild(message);
    return;
  }

  const periodEvents = (events || []).filter((event) => event.start && eventOverlapsPeriod(event, periodStart, periodEnd));
  countElement.textContent = String(periodEvents.length);
  if (!periodEvents.length) {
    const empty = document.createElement("p");
    empty.className = "home-loading";
    empty.textContent = "Nothing scheduled";
    container.appendChild(empty);
    return;
  }

  periodEvents.forEach((event) => {
    const item = document.createElement("article");
    item.className = "home-event-item";
    const date = document.createElement("span");
    date.className = "home-event-date";
    date.textContent = formatHomeEventDate(event);
    const time = document.createElement("span");
    time.className = "home-event-time";
    time.textContent = formatHomeEventTime(event);
    const title = document.createElement("strong");
    title.textContent = event.summary || "(no title)";
    item.append(date, time, title);
    if (event.location) {
      const location = document.createElement("span");
      location.className = "home-event-location";
      location.textContent = event.location;
      item.appendChild(location);
    }
    container.appendChild(item);
  });
}

function getHomeAccessToken(interactive) {
  return new Promise((resolve, reject) => {
    chrome.identity.getAuthToken({ interactive, scopes: GOOGLE_AUTH_SCOPES }, (token) => {
      const authError = chrome.runtime.lastError;
      if (authError || !token) {
        reject(new Error(authError?.message || "Google sign-in token unavailable. Sign in again to load your overview."));
        return;
      }
      googleAccessToken = token;
      resolve(token);
    });
  });
}

async function ensureHomeAccessToken() {
  if (googleAccessToken) return googleAccessToken;
  try {
    return await getHomeAccessToken(false);
  } catch {
    return getHomeAccessToken(true);
  }
}

async function fetchHomeGoogleJson(url, token) {
  let response = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  if (response.status === 401) {
    await new Promise((resolve) => chrome.identity.removeCachedAuthToken({ token }, resolve));
    googleAccessToken = null;
    token = await ensureHomeAccessToken();
    response = await fetch(url, { headers: { Authorization: `Bearer ${token}` } });
  }

  const data = await response.json();
  if (!response.ok) throw new Error(data.error?.message || "Google API request failed.");
  return data;
}

async function getHomeDashboardData(todayStart) {
  const token = await ensureHomeAccessToken();
  const thisWeekStart = getHomeWeekStart(todayStart);
  const weekAfterNextStart = new Date(thisWeekStart);
  weekAfterNextStart.setDate(weekAfterNextStart.getDate() + 14);

  const gmailUrl = new URL("https://gmail.googleapis.com/gmail/v1/users/me/messages");
  gmailUrl.searchParams.append("labelIds", "INBOX");
  gmailUrl.searchParams.append("labelIds", "UNREAD");
  gmailUrl.searchParams.set("q", "category:primary");
  gmailUrl.searchParams.set("maxResults", "1");

  const recentGmailUrl = new URL("https://gmail.googleapis.com/gmail/v1/users/me/messages");
  recentGmailUrl.searchParams.append("labelIds", "INBOX");
  recentGmailUrl.searchParams.set("maxResults", "5");

  const calendarUrl = new URL("https://www.googleapis.com/calendar/v3/calendars/primary/events");
  calendarUrl.searchParams.set("timeMin", thisWeekStart.toISOString());
  calendarUrl.searchParams.set("timeMax", weekAfterNextStart.toISOString());
  calendarUrl.searchParams.set("maxResults", "250");
  calendarUrl.searchParams.set("singleEvents", "true");
  calendarUrl.searchParams.set("orderBy", "startTime");

  const [gmailResult, recentGmailResult, calendarResult] = await Promise.allSettled([
    fetchHomeGoogleJson(gmailUrl.toString(), token).then((data) => Number(data.resultSizeEstimate || 0)),
    fetchHomeGoogleJson(recentGmailUrl.toString(), token).then(async (data) => {
      const messages = Array.isArray(data.messages) ? data.messages : [];
      return Promise.all(messages.slice(0, 5).map(async (message) => {
        const detailUrl = new URL(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${encodeURIComponent(message.id)}`);
        detailUrl.searchParams.set("format", "metadata");
        detailUrl.searchParams.append("metadataHeaders", "From");
        detailUrl.searchParams.append("metadataHeaders", "Subject");
        detailUrl.searchParams.append("metadataHeaders", "Date");
        const detail = await fetchHomeGoogleJson(detailUrl.toString(), token);
        const headers = detail.payload?.headers || [];
        const getHeader = (name) => headers.find((header) => header.name?.toLowerCase() === name.toLowerCase())?.value || "";
        const date = detail.internalDate
          ? new Date(Number(detail.internalDate))
          : new Date(getHeader("Date"));
        return {
          id: detail.id,
          from: getHeader("From") || "Unknown sender",
          subject: getHeader("Subject") || "(no subject)",
          date: Number.isNaN(date.getTime()) ? "" : date.toISOString(),
          snippet: detail.snippet || ""
        };
      }));
    }),
    fetchHomeGoogleJson(calendarUrl.toString(), token).then((data) => Array.isArray(data.items)
      ? data.items.filter((event) => event.status !== "cancelled").map((event) => ({
        id: event.id,
        summary: event.summary || "(no title)",
        start: event.start?.dateTime || event.start?.date || null,
        end: event.end?.dateTime || event.end?.date || null,
        location: event.location || ""
      }))
      : [])
  ]);

  return {
    unreadCount: gmailResult.status === "fulfilled" ? gmailResult.value : null,
    gmailError: gmailResult.status === "rejected" ? gmailResult.reason.message : null,
    recentEmails: recentGmailResult.status === "fulfilled" ? recentGmailResult.value : null,
    recentEmailsError: recentGmailResult.status === "rejected" ? recentGmailResult.reason.message : null,
    events: calendarResult.status === "fulfilled" ? calendarResult.value : null,
    calendarError: calendarResult.status === "rejected" ? calendarResult.reason.message : null
  };
}

function formatHomeEmailDate(dateValue) {
  const date = new Date(dateValue);
  if (Number.isNaN(date.getTime())) return "";
  return new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric" }).format(date);
}

function renderHomeEmails(emails, error) {
  recentEmailsContainer.replaceChildren();
  if (error) {
    const message = document.createElement("p");
    message.className = "home-loading home-error";
    message.textContent = error;
    recentEmailsContainer.appendChild(message);
    return;
  }

  if (!emails?.length) {
    const empty = document.createElement("p");
    empty.className = "home-loading";
    empty.textContent = "No recent email";
    recentEmailsContainer.appendChild(empty);
    return;
  }

  emails.forEach((email) => {
    const item = document.createElement("article");
    item.className = "home-email-item";

    const header = document.createElement("div");
    header.className = "home-email-item-header";
    const sender = document.createElement("span");
    sender.className = "home-email-sender";
    sender.textContent = email.from;
    const date = document.createElement("time");
    date.className = "home-email-date";
    if (email.date) date.dateTime = email.date;
    date.textContent = formatHomeEmailDate(email.date);
    header.append(sender, date);

    const subject = document.createElement("strong");
    subject.className = "home-email-subject";
    subject.textContent = email.subject;
    item.append(header, subject);

    if (email.snippet) {
      const snippet = document.createElement("p");
      snippet.className = "home-email-snippet";
      snippet.textContent = email.snippet;
      item.appendChild(snippet);
    }
    recentEmailsContainer.appendChild(item);
  });
}

async function loadHomeDashboard() {
  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);
  const thisWeekStart = getHomeWeekStart(todayStart);
  const nextWeekStart = new Date(thisWeekStart);
  nextWeekStart.setDate(nextWeekStart.getDate() + 7);
  const weekAfterNextStart = new Date(nextWeekStart);
  weekAfterNextStart.setDate(weekAfterNextStart.getDate() + 7);
  unreadEmailCount.textContent = "...";
  unreadEmailStatus.textContent = "Loading Gmail...";
  recentEmailsContainer.innerHTML = '<p class="home-loading">Loading email...</p>';
  thisWeekEventsContainer.innerHTML = '<p class="home-loading">Loading calendar...</p>';
  nextWeekEventsContainer.innerHTML = '<p class="home-loading">Loading calendar...</p>';
  thisWeekEventCount.textContent = "...";
  nextWeekEventCount.textContent = "...";

  try {
    const response = await getHomeDashboardData(todayStart);
    if (response.unreadCount === null) {
      unreadEmailCount.textContent = "--";
      unreadEmailStatus.textContent = response.gmailError || "Gmail could not be loaded.";
    } else {
      unreadEmailCount.textContent = response.unreadCount.toLocaleString();
      unreadEmailStatus.textContent = response.unreadCount === 1 ? "unread message" : "unread messages";
    }
    renderHomeEmails(response.recentEmails, response.recentEmailsError);
    renderHomeEvents(thisWeekEventsContainer, thisWeekEventCount, response.events, thisWeekStart, nextWeekStart, response.calendarError);
    renderHomeEvents(nextWeekEventsContainer, nextWeekEventCount, response.events, nextWeekStart, weekAfterNextStart, response.calendarError);
  } catch (error) {
    unreadEmailCount.textContent = "--";
    unreadEmailStatus.textContent = error.message;
    renderHomeEmails(null, error.message);
    renderHomeEvents(thisWeekEventsContainer, thisWeekEventCount, [], thisWeekStart, nextWeekStart, error.message);
    renderHomeEvents(nextWeekEventsContainer, nextWeekEventCount, [], nextWeekStart, weekAfterNextStart, error.message);
  }
}

homeButton.addEventListener("click", () => {
  document.body.classList.add("home-view-active");
  homeDashboard.hidden = false;
  homeButton.setAttribute("aria-pressed", "true");
  loadHomeDashboard();
});
homeRefreshButton.addEventListener("click", loadHomeDashboard);


function signInToGoogle() {
  return new Promise((resolve) => {
    requestFreshGoogleAccessToken().then((token) => {
      const authError = chrome.runtime.lastError;
      if (authError || !token) {
        const errorMessage = authError?.message || "No token received and no specific error message.";
        if (errorMessage.includes("bad client id")) {
          console.error(
            "Authentication Error: The OAuth client ID is not registered for this extension. " +
            "Create a Chrome App OAuth client for extension ID " + chrome.runtime.id +
            " and update oauth2.client_id in manifest.json.",
            authError
          );
        } else {
          console.error("Authentication Error:", errorMessage);
        }
        resolve(false);
        return;
      }

      googleAccessToken = token;

      fetch("https://www.googleapis.com/oauth2/v2/userinfo", {
        headers: { Authorization: `Bearer ${token}` }
      })
      .then(res => res.json())
      .then(profile => {
        chrome.storage.local.set({ googleUser: profile }, () => {
          if (chrome.runtime.lastError) {
            console.error("Could not save signed-in profile:", chrome.runtime.lastError);
            resolve(false);
            return;
          }
          currentUser = profile;
          updateUserUI(profile);
          loadChatsForUser(profile)
            .then(() => {
              showWalkthroughIfNeeded(profile);
              resolve(true);
            })
            .catch((error) => {
              console.error("Could not load chats for signed-in account:", error);
              resolve(false);
            });
        });
      })
      .catch(err => {
        console.error("Profile Fetch Error:", err);
        resolve(false);
      });
    });
  });
}

if (authCardSignIn) {
  authCardSignIn.addEventListener("click", () => signInToGoogle());
}

walkthroughBackButton.addEventListener("click", () => {
  if (walkthroughStep > 0) {
    walkthroughStep -= 1;
    renderWalkthroughStep();
  }
});
walkthroughNextButton.addEventListener("click", () => {
  if (walkthroughStep < WALKTHROUGH_STEPS.length - 1) {
    walkthroughStep += 1;
    renderWalkthroughStep();
  } else {
    finishWalkthrough();
  }
});
walkthroughSkipButton.addEventListener("click", finishWalkthrough);

profileButton.addEventListener("click", () => {
  const isOpen = !profileMenu.hidden;
  profileMenu.hidden = isOpen;
  profileButton.setAttribute("aria-expanded", String(!isOpen));
});

settingsButton.addEventListener("click", openSettings);
signOutButton.addEventListener("click", signOutOfVoyager);
closeSettingsButton.addEventListener("click", closeSettings);
cancelSettingsButton.addEventListener("click", closeSettings);
settingsOverlay.addEventListener("click", (event) => {
  if (event.target === settingsOverlay) closeSettings();
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !settingsOverlay.hidden) closeSettings();
});
welcomeMessageInput.addEventListener("input", updateWelcomePreview);
preferredNameInput.addEventListener("input", updateWelcomePreview);
useNameInGreeting.addEventListener("change", updateWelcomePreview);
personalizationForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const storageKey = getWelcomePreferencesStorageKey(currentUser);
  const preferences = normalizePersonalizationPreferences({
    agentDisplayName: agentDisplayNameInput.value,
    communicationTone: communicationToneInput.value,
    responseDetail: responseDetailInput.value,
    responseFormat: responseFormatInput.value,
    autonomyPreference: autonomyPreferenceInput.value,
    customInstructions: customInstructionsInput.value,
    message: welcomeMessageInput.value.trim() || DEFAULT_WELCOME_MESSAGE,
    preferredName: preferredNameInput.value.trim(),
    useName: useNameInGreeting.checked
  });
  chrome.storage.local.set({ [storageKey]: preferences }, () => {
    const storageError = chrome.runtime.lastError;
    if (storageError) {
      console.error("Could not save personalization settings:", storageError);
      settingsStatus.textContent = "Could not save your settings. Please try again.";
      return;
    }
    welcomePreferences = preferences;
    renderWelcomeMessage();
    settingsStatus.textContent = "Settings saved.";
  });
});

function deleteAccountData() {
  if (!currentUser || !window.confirm("Delete your account data from Voyager? This cannot be undone.")) return;

  chrome.storage.local.clear(() => {
    chrome.identity.clearAllCachedAuthTokens(() => {
      currentUser = null;
      googleAccessToken = null;
      chats = [];
      activeChatId = null;
      agentLogsByMessageId.clear();
      profileMenu.hidden = true;
      closeSettings();
      updateUserUI(null);
      renderActiveChat();
    });
  });
}

function clearGoogleAuthTokens() {
  return new Promise((resolve, reject) => {
    chrome.identity.clearAllCachedAuthTokens(() => {
      const authError = chrome.runtime.lastError;
      if (authError) {
        reject(new Error(authError.message));
        return;
      }
      resolve();
    });
  });
}

function removeStoredGoogleProfile() {
  return new Promise((resolve, reject) => {
    chrome.storage.local.remove("googleUser", () => {
      const storageError = chrome.runtime.lastError;
      if (storageError) {
        reject(new Error(storageError.message));
        return;
      }
      resolve();
    });
  });
}

async function signOutOfVoyager() {
  if (!currentUser) return;
  profileMenu.hidden = true;
  profileButton.setAttribute("aria-expanded", "false");
  resolveWorkspaceWriteDecision(false);
  chrome.runtime.sendMessage({ action: "sign_out", chatId: activeChatId });

  try {
    await clearGoogleAuthTokens();
    await removeStoredGoogleProfile();
    googleAccessToken = null;
    chats = [];
    activeChatId = null;
    continueCurrentChat = true;
    agentLogsByMessageId.clear();
    updateUserUI(null);
    renderActiveChat();
  } catch (error) {
    console.error("Could not sign out of Voyager:", error);
    window.alert(`Could not sign out: ${error.message}`);
  }
}

deleteAccountButton.addEventListener("click", deleteAccountData);

function updateUserUI(user) {
  currentUser = user;
  loadWelcomePreferences(user);
  const signedOut = !user;
  document.body.classList.toggle("signed-out", signedOut);
  if (user) {
    profileMenuName.textContent = user.name || user.email;
    if (user.picture) {
      sidebarUserAvatar.src = user.picture;
      sidebarUserAvatar.style.display = "block";
    } else {
      sidebarUserAvatar.removeAttribute("src");
      sidebarUserAvatar.style.display = "none";
    }
    profileButton.title = user.name || user.email || "Open profile menu";
  } else {
    profileMenuName.textContent = "Not signed in";
    sidebarUserAvatar.removeAttribute("src");
    sidebarUserAvatar.style.display = "none";
    profileButton.title = "Open profile menu";
    profileButton.setAttribute("aria-expanded", "false");
  }
}

const WORKSPACE_DATABASE_NAME = "voyager-local-workspace";
const WORKSPACE_DATABASE_VERSION = 1;
const WORKSPACE_MAX_TEXT_BYTES = 50 * 1024;
const WORKSPACE_TEXT_EXTENSIONS = new Set([
  "txt", "md", "markdown", "csv", "tsv", "json", "jsonc", "xml", "html", "htm",
  "css", "js", "mjs", "cjs", "ts", "tsx", "jsx", "py", "java", "c", "h", "cpp",
  "hpp", "cs", "go", "rs", "rb", "php", "sql", "sh", "bat", "ps1", "yaml", "yml",
  "toml", "ini", "cfg", "conf", "log", "svg", "gitignore", "editorconfig"
]);

function openWorkspaceDatabase() {
  if (workspaceDatabasePromise) return workspaceDatabasePromise;
  workspaceDatabasePromise = new Promise((resolve, reject) => {
    if (!window.indexedDB) {
      reject(new Error("This browser does not support saved local-folder access."));
      return;
    }

    const request = window.indexedDB.open(WORKSPACE_DATABASE_NAME, WORKSPACE_DATABASE_VERSION);
    request.onupgradeneeded = () => {
      if (!request.result.objectStoreNames.contains("handles")) {
        request.result.createObjectStore("handles");
      }
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error || new Error("Could not open local-folder storage."));
  });
  return workspaceDatabasePromise;
}

async function getStoredWorkspaceHandle() {
  const database = await openWorkspaceDatabase();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction("handles", "readonly");
    const request = transaction.objectStore("handles").get("selected-directory");
    request.onsuccess = () => resolve(request.result || null);
    request.onerror = () => reject(request.error || new Error("Could not restore the selected folder."));
  });
}

async function storeWorkspaceHandle(handle) {
  const database = await openWorkspaceDatabase();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction("handles", "readwrite");
    transaction.objectStore("handles").put(handle, "selected-directory");
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error || new Error("Could not save the selected folder."));
    transaction.onabort = () => reject(transaction.error || new Error("Saving the selected folder was cancelled."));
  });
}

async function removeStoredWorkspaceHandle() {
  const database = await openWorkspaceDatabase();
  return new Promise((resolve, reject) => {
    const transaction = database.transaction("handles", "readwrite");
    transaction.objectStore("handles").delete("selected-directory");
    transaction.oncomplete = () => resolve();
    transaction.onerror = () => reject(transaction.error || new Error("Could not disconnect the selected folder."));
    transaction.onabort = () => reject(transaction.error || new Error("Disconnecting the selected folder was cancelled."));
  });
}

async function refreshWorkspaceStatus() {
  if (!workspaceDirectoryHandle) {
    workspaceFolderName.textContent = "No local folder selected";
    workspaceStatus.textContent = "Choose a folder to let Voyager work with text files inside it. Files you ask it to read are shared with the AI to complete your request.";
    chooseWorkspaceButton.textContent = "Connect a folder";
    workspaceMenuButton.title = "Connect a folder";
    workspaceMenuButton.setAttribute("aria-label", "Connect a folder");
    reconnectWorkspaceButton.hidden = true;
    removeWorkspaceButton.hidden = true;
    return;
  }

  workspaceFolderName.textContent = workspaceDirectoryHandle.name;
  chooseWorkspaceButton.textContent = "Change folder";
  workspaceMenuButton.title = `Local folder: ${workspaceDirectoryHandle.name}`;
  workspaceMenuButton.setAttribute("aria-label", `Local folder connected: ${workspaceDirectoryHandle.name}`);
  removeWorkspaceButton.hidden = false;
  try {
    const permission = await workspaceDirectoryHandle.queryPermission({ mode: "readwrite" });
    const isGranted = permission === "granted";
    reconnectWorkspaceButton.hidden = isGranted;
    workspaceStatus.textContent = isGranted
      ? "Connected. Voyager can list and read text files here; every file change requires your approval. Files read are shared with the AI."
      : "This folder is saved, but browser access needs to be reconnected before Voyager can use it.";
  } catch (error) {
    console.error("Could not check local-folder access:", error);
    reconnectWorkspaceButton.hidden = false;
    workspaceStatus.textContent = `Could not check folder access: ${error.message}`;
  }
}

async function chooseWorkspaceFolder() {
  if (typeof window.showDirectoryPicker !== "function") {
    workspaceStatus.textContent = "This browser does not support choosing a local folder. Use a current version of Chrome or Edge.";
    return;
  }

  try {
    workspaceStatus.textContent = "Choose a folder in the browser dialog...";
    const handle = await window.showDirectoryPicker({ id: "voyager-local-workspace", mode: "readwrite" });
    await storeWorkspaceHandle(handle);
    workspaceDirectoryHandle = handle;
    await refreshWorkspaceStatus();
  } catch (error) {
    if (error.name === "AbortError") {
      await refreshWorkspaceStatus();
      return;
    }
    console.error("Could not select a local workspace folder:", error);
    workspaceStatus.textContent = `Could not select the folder: ${error.message}`;
  }
}

async function reconnectWorkspaceFolder() {
  if (!workspaceDirectoryHandle) return;
  try {
    const permission = await workspaceDirectoryHandle.requestPermission({ mode: "readwrite" });
    if (permission !== "granted") {
      workspaceStatus.textContent = "Access was not granted. Choose the folder again to reconnect it.";
      return;
    }
    await refreshWorkspaceStatus();
  } catch (error) {
    console.error("Could not reconnect local-folder access:", error);
    workspaceStatus.textContent = `Could not reconnect the folder: ${error.message}`;
  }
}

async function disconnectWorkspaceFolder() {
  try {
    await removeStoredWorkspaceHandle();
    workspaceDirectoryHandle = null;
    await refreshWorkspaceStatus();
  } catch (error) {
    console.error("Could not disconnect the local workspace folder:", error);
    workspaceStatus.textContent = `Could not disconnect the folder: ${error.message}`;
  }
}

function validateWorkspacePath(path) {
  if (typeof path !== "string" || !path || path.length > 500 || /[\\\u0000-\u001f:]/.test(path)) {
    throw new Error("Use a relative file path inside the selected folder.");
  }
  const segments = path.split("/");
  if (segments.length > 20 || segments.some((segment) => !segment || segment === "." || segment === "..")) {
    throw new Error("The file path must not be empty or escape the selected folder.");
  }
  return segments;
}

function isSupportedWorkspaceTextFile(name, mimeType = "") {
  const extension = name.split(".").pop().toLowerCase();
  return mimeType.startsWith("text/")
    || mimeType === "application/json"
    || mimeType === "application/xml"
    || WORKSPACE_TEXT_EXTENSIONS.has(extension);
}

async function requireWorkspacePermission(mode) {
  if (!workspaceDirectoryHandle) {
    throw new Error("No local workspace folder is selected. Choose a folder in the Voyager panel first.");
  }
  const permission = await workspaceDirectoryHandle.queryPermission({ mode });
  if (permission !== "granted") {
    await refreshWorkspaceStatus();
    throw new Error("Local folder access is not active. Reconnect the folder in the Voyager panel and try again.");
  }
}

async function getWorkspaceDirectory(relativeSegments, create = false) {
  let directory = workspaceDirectoryHandle;
  for (const segment of relativeSegments) {
    directory = await directory.getDirectoryHandle(segment, { create });
  }
  return directory;
}

function getModePlaceholder() {
  return selectedMode === "code"
    ? "Describe code changes for the connected folder..."
    : "Ask the agent to do something...";
}

function shouldUseCodeModeForRequest(objective) {
  const text = String(objective || "");
  const productNameRewrite = /\b(?:make|rewrite|improve|rename|polish|update|change)\b.{0,60}\b(?:clothes?|clothing|apparel|product|item)\s+(?:names?|titles?)\b|\b(?:clothes?|clothing|apparel|product|item)\s+(?:names?|titles?)\b.{0,60}\b(?:attractive|appealing|catchy|compelling|rewrite|improve|rename)\b/i;
  const explicitCodeTask = /\b(?:in|from|using|through)\s+(?:the\s+)?(?:provided\s+)?(?:source\s+)?code\b|\b(?:source\s+code|project files|codebase|code provided)\b/i;
  return productNameRewrite.test(text) || explicitCodeTask.test(text);
}

function setSelectedMode(mode, persist = true) {
  selectedMode = mode === "code" ? "code" : "agent";
  for (const [button, buttonMode] of [[agentModeButton, "agent"], [codeModeButton, "code"]]) {
    const selected = selectedMode === buttonMode;
    button.classList.toggle("selected", selected);
    button.setAttribute("aria-checked", String(selected));
    button.tabIndex = selected ? 0 : -1;
  }
  objectiveInput.placeholder = getModePlaceholder();
  if (persist) {
    chrome.storage.local.set({ voyagerMode: selectedMode }, () => {
      if (chrome.runtime.lastError) console.error("Could not save Voyager mode:", chrome.runtime.lastError);
    });
  }
}

async function listWorkspaceEntries(relativePath = "") {
  await requireWorkspacePermission("read");
  const segments = relativePath ? validateWorkspacePath(relativePath) : [];
  const directory = await getWorkspaceDirectory(segments);
  const entries = [];
  for await (const [name, handle] of directory.entries()) {
    entries.push({ name, kind: handle.kind });
  }
  entries.sort((first, second) => first.name.localeCompare(second.name));
  return { path: relativePath || ".", entries: entries.slice(0, 200), truncated: entries.length > 200 };
}

async function readWorkspaceFile(relativePath) {
  await requireWorkspacePermission("read");
  const segments = validateWorkspacePath(relativePath);
  const name = segments[segments.length - 1];
  const directory = await getWorkspaceDirectory(segments.slice(0, -1));
  const handle = await directory.getFileHandle(name);
  const file = await handle.getFile();
  if (!isSupportedWorkspaceTextFile(name, file.type)) {
    throw new Error("Voyager can read text files only (for example .txt, .md, .csv, .json, or source-code files).");
  }
  if (file.size > WORKSPACE_MAX_TEXT_BYTES) {
    throw new Error(`This file is larger than the ${WORKSPACE_MAX_TEXT_BYTES / 1024} KB text-file limit.`);
  }
  const content = await file.text();
  if (content.includes("\u0000")) {
    throw new Error("This file appears to contain binary data and cannot be read as text.");
  }
  return { path: relativePath, content };
}

function askToApproveWorkspaceWrite({ path, previousContent, content, exists, parentDirectoriesMissing }) {
  workspaceWritePath.textContent = `${workspaceDirectoryHandle.name}/${path}${exists ? " (overwrite)" : " (new file)"}`;
  workspacePreviousContent.textContent = previousContent;
  workspaceProposedContent.textContent = content;
  workspacePreviousContentSection.hidden = !exists;
  workspaceWriteStatus.textContent = exists
    ? "Voyager will replace this file with the proposed content only if you approve."
    : `Voyager will create this file${parentDirectoriesMissing ? " and any missing parent folders" : ""} only if you approve.`;
  workspaceWriteOverlay.hidden = false;
  approveWorkspaceWriteButton.focus();

  return new Promise((resolve) => {
    pendingWorkspaceWriteDecision = resolve;
  });
}

function resolveWorkspaceWriteDecision(approved) {
  if (!pendingWorkspaceWriteDecision) return;
  const resolve = pendingWorkspaceWriteDecision;
  pendingWorkspaceWriteDecision = null;
  workspaceWriteOverlay.hidden = true;
  if (!approved) workspaceStatus.textContent = "The proposed file change was cancelled; nothing was saved.";
  resolve(approved);
}

async function writeWorkspaceFile(relativePath, content) {
  await requireWorkspacePermission("readwrite");
  if (typeof content !== "string") throw new Error("The proposed file content must be text.");
  if (new TextEncoder().encode(content).byteLength > WORKSPACE_MAX_TEXT_BYTES) {
    throw new Error(`Proposed content exceeds the ${WORKSPACE_MAX_TEXT_BYTES / 1024} KB text-file limit.`);
  }

  const segments = validateWorkspacePath(relativePath);
  const name = segments[segments.length - 1];
  if (!isSupportedWorkspaceTextFile(name)) {
    throw new Error("Voyager can write text files only. Use a filename such as notes.md or data.csv.");
  }
  let directory = null;
  let parentDirectoriesMissing = false;
  try {
    directory = await getWorkspaceDirectory(segments.slice(0, -1));
  } catch (error) {
    if (error.name !== "NotFoundError") throw error;
    parentDirectoriesMissing = true;
  }
  let fileHandle = null;
  let previousContent = "";
  let exists = false;
  if (directory) {
    try {
      fileHandle = await directory.getFileHandle(name);
      const existingFile = await fileHandle.getFile();
      if (!isSupportedWorkspaceTextFile(name, existingFile.type)) {
        throw new Error("The existing file is not a supported text file.");
      }
      if (existingFile.size > WORKSPACE_MAX_TEXT_BYTES) {
        throw new Error(`The existing file is larger than the ${WORKSPACE_MAX_TEXT_BYTES / 1024} KB limit and cannot be safely previewed.`);
      }
      previousContent = await existingFile.text();
      if (previousContent.includes("\u0000")) throw new Error("The existing file appears to contain binary data.");
      exists = true;
    } catch (error) {
      if (error.name !== "NotFoundError") throw error;
      fileHandle = null;
    }
  }

  const approved = await askToApproveWorkspaceWrite({
    path: relativePath,
    previousContent,
    content,
    exists,
    parentDirectoriesMissing
  });
  if (!approved) throw new Error("The proposed local file change was cancelled; nothing was saved.");

  if (!directory) directory = await getWorkspaceDirectory(segments.slice(0, -1), true);
  if (exists) {
    const latestContent = await (await fileHandle.getFile()).text();
    if (latestContent !== previousContent) {
      throw new Error("This file changed while the approval dialog was open. Review the latest version and try again.");
    }
  } else {
    try {
      await directory.getFileHandle(name);
      throw new Error("A file with this name appeared while the approval dialog was open. Review it before replacing anything.");
    } catch (error) {
      if (error.name !== "NotFoundError") throw error;
    }
  }
  fileHandle = fileHandle || await directory.getFileHandle(name, { create: true });
  const writable = await fileHandle.createWritable();
  try {
    await writable.write(content);
    await writable.close();
  } catch (error) {
    await writable.abort().catch(() => {});
    throw error;
  }
  await refreshWorkspaceStatus();
  return { path: relativePath, overwritten: exists };
}

async function handleWorkspaceOperation(message) {
  if (message.operation === "list") return { ok: true, result: await listWorkspaceEntries(message.path || "") };
  if (message.operation === "read") return { ok: true, result: await readWorkspaceFile(message.path) };
  if (message.operation === "write") {
    return { ok: true, result: await writeWorkspaceFile(message.path, message.content) };
  }
  return { ok: false, error: "Unsupported local workspace operation." };
}

function setDriveStatus(message) {
  if (driveStatus) {
    driveStatus.textContent = message;
  }
}

async function ensureDriveAccess() {
  if (googleAccessToken) return googleAccessToken;
  googleAccessToken = await requestFreshGoogleAccessToken();
  return googleAccessToken;
}

async function listDriveFiles() {
  const token = await ensureDriveAccess();
  if (!token) {
    setDriveStatus("Please sign in to Google Drive first.");
    return;
  }

  setDriveStatus("Loading your Drive files...");
  chrome.runtime.sendMessage({ action: "list_drive_files" }, (response) => {
    if (chrome.runtime.lastError) {
      setDriveStatus(`Drive listing failed: ${chrome.runtime.lastError.message}`);
      return;
    }

    if (!response || !response.ok) {
      setDriveStatus(`Drive listing failed: ${response?.error || "Unknown error"}`);
      return;
    }

    const files = Array.isArray(response.files) ? response.files : [];
    if (!files.length) {
      setDriveStatus("No files were found in the connected Google Drive.");
      return;
    }

    const summary = files
      .slice(0, 20)
      .map((file) => `${file.name} (${file.mimeType || "unknown type"})`)
      .join("\n");

    setDriveStatus(summary + (files.length > 20 ? `\n...and ${files.length - 20} more` : ""));
  });
}

async function createDriveFolder() {
  const token = await ensureDriveAccess();
  if (!token) {
    setDriveStatus("Please sign in to Google Drive first.");
    return;
  }

  const folderName = (driveFolderNameInput.value || "").trim();
  if (!folderName) {
    setDriveStatus("Enter a folder name before creating a Drive folder.");
    return;
  }

  setDriveStatus(`Creating folder "${folderName}"...`);
  chrome.runtime.sendMessage({ action: "create_drive_folder", folderName }, (response) => {
    if (chrome.runtime.lastError) {
      setDriveStatus(`Folder creation failed: ${chrome.runtime.lastError.message}`);
      return;
    }

    if (!response || !response.ok) {
      setDriveStatus(`Folder creation failed: ${response?.error || "Unknown error"}`);
      return;
    }

    setDriveStatus(`Created folder: ${response.folder?.name || folderName}`);
    driveFolderNameInput.value = "";
  });
}

async function createDriveDoc() {
  const token = await ensureDriveAccess();
  if (!token) {
    setDriveStatus("Please sign in to Google Drive first.");
    return;
  }

  const fileName = (driveFileNameInput.value || "").trim();
  const content = (driveFileContentInput.value || "").trim();
  if (!fileName) {
    setDriveStatus("Enter a document name before creating a Drive file.");
    return;
  }

  setDriveStatus(`Creating Drive document "${fileName}"...`);
  chrome.runtime.sendMessage({
    action: "create_drive_file",
    name: fileName,
    mimeType: "application/vnd.google-apps.document",
    content
  }, (response) => {
    if (chrome.runtime.lastError) {
      setDriveStatus(`Document creation failed: ${chrome.runtime.lastError.message}`);
      return;
    }

    if (!response || !response.ok) {
      setDriveStatus(`Document creation failed: ${response?.error || "Unknown error"}`);
      return;
    }

    const fileNameResult = response.file?.name || fileName;
    setDriveStatus(`Created Drive document: ${fileNameResult}`);
    driveFileNameInput.value = "";
    driveFileContentInput.value = "";
  });
}

// Append a message to the active chat and persist the complete transcript.
function addMessage(text, sender = "system", targetChatId = activeChatId) {
  const chat = chats.find((item) => item.id === targetChatId);
  if (!chat) return null;
  const message = { id: crypto.randomUUID(), sender, text, timestamp: new Date().toISOString() };
  chat.messages.push(message);
  chat.updatedAt = message.timestamp;
  if (sender === "user" && chat.title === "New conversation") {
    chat.title = text.slice(0, 42) || "New conversation";
  }
  let bubble = null;
  if (chat.id === activeChatId) {
    emptyChatState.hidden = true;
    bubble = renderMessage(text, sender, message);
    chatContainer.scrollTop = chatContainer.scrollHeight;
  }
  persistChats();
  renderChatList();
  return bubble;
}

function refreshChatInputPlaceholder() {
  const chatId = activeChatId;
  if (!chatId) {
    objectiveInput.placeholder = getModePlaceholder();
    return;
  }
  chrome.runtime.sendMessage({ action: "get_pending_agent_run", chatId }, (response) => {
    if (chrome.runtime.lastError || activeChatId !== chatId) return;
    if (response?.pending && response.question) {
      const chat = chats.find((item) => item.id === chatId);
      const questionAlreadyVisible = chat?.messages.some((message) =>
        message.sender === "agent" && message.text === response.question
      );
      if (chat && !questionAlreadyVisible) addMessage(response.question, "agent", chatId);
    }
    objectiveInput.placeholder = response?.pending
      ? "Answer the agent's question..."
      : getModePlaceholder();
  });
}

// Keep track of the step count locally
let currentStep = 0;
const maxSteps = 15;

function setAgentState(isRunning) {
  if (isRunning) {
    agentStateContainer.style.display = 'block';
    idleStateContainer.style.display = 'none';
    stopButton.style.display = 'inline-block';
  } else {
    agentStateContainer.style.display = 'none';
    idleStateContainer.style.display = 'flex';
    stopButton.style.display = 'none';
    startButton.disabled = false;
    objectiveInput.disabled = false;
  }
}
function getLogIconSvg(logText) {
  const lower = logText.toLowerCase();
  
  // Thought / Reasoning
  if (lower.includes('thought') || lower.includes('reasoning')) {
    return `<svg class="log-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 14c.2-1 .7-1.7 1.5-2.5 1-.9 1.5-2.2 1.5-3.5A6 6 0 0 0 6 8c0 1 .2 2.2 1.5 3.5.7.7 1.3 1.5 1.5 2.5"/><path d="M9 18h6"/><path d="M10 22h4"/></svg>`;
  }
  // Click
  if (lower.includes('click')) {
    return `<svg class="log-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m3 3 7.07 16.97 2.51-7.39 7.39-2.51L3 3z"/><path d="m13 13 6 6"/></svg>`;
  }
  // Type / Input
  if (lower.includes('type') || lower.includes('input') || lower.includes('clear')) {
    return `<svg class="log-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#818cf8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="20" height="16" x="2" y="4" rx="2"/><path d="M6 8h.001"/><path d="M10 8h.001"/><path d="M14 8h.001"/><path d="M18 8h.001"/><path d="M8 12h.001"/><path d="M12 12h.001"/><path d="M16 12h.001"/><path d="M7 16h10"/></svg>`;
  }
  // Key press
  if (lower.includes('key')) {
    return `<svg class="log-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 3a3 3 0 0 0-3 3v12a3 3 0 0 0 3 3 3 3 0 0 0 3-3 3 3 0 0 0-3-3H6a3 3 0 0 0-3 3 3 3 0 0 0 3 3 3 3 0 0 0 3-3V6a3 3 0 0 0-3-3 3 3 0 0 0-3 3 3 3 0 0 0 3 3h12a3 3 0 0 0 3-3 3 3 0 0 0-3-3z"/></svg>`;
  }
  // Hover
  if (lower.includes('hover')) {
    return `<svg class="log-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 11V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v0"/><path d="M14 10V4a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v2"/><path d="M10 10.5V6a2 2 0 0 0-2-2v0a2 2 0 0 0-2 2v8"/><path d="M18 8a2 2 0 1 1 4 0v6a8 8 0 0 1-8 8h-2c-2.8 0-4.5-.86-5.99-2.34l-3.6-3.6a2 2 0 0 1 2.83-2.82L7 15"/></svg>`;
  }
  // Select
  if (lower.includes('select')) {
    return `<svg class="log-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>`;
  }
  // Scroll
  if (lower.includes('scroll')) {
    return `<svg class="log-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="8 18 12 22 16 18"/><polyline points="8 6 12 2 16 6"/><line x1="12" y1="2" x2="12" y2="22"/></svg>`;
  }
  // Navigation / URL
  if (lower.includes('navigating') || lower.includes('url') || lower.includes('navigate')) {
    return `<svg class="log-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#38bdf8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>`;
  }
  // Analyzing / Screenshot / Thinking / Learning
  if (lower.includes('analyzing') || lower.includes('screenshot') || lower.includes('reflecting') || lower.includes('learned') || lower.includes('memory') || lower.includes('summarizing')) {
    return `<svg class="log-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#a855f7" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3L12 3z"/></svg>`;
  }
  // Error
  if (lower.includes('error') || lower.includes('failed')) {
    return `<svg class="log-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#ef4444" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="15" y1="9" x2="9" y2="15"/><line x1="9" y1="9" x2="15" y2="15"/></svg>`;
  }
  // Warning
  if (lower.includes('warning') || lower.includes('attempt failed')) {
    return `<svg class="log-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#f59e0b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;
  }
  // Stop / Finish
  if (lower.includes('stop') || lower.includes('complete') || lower.includes('finished')) {
    return `<svg class="log-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#10b981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><polyline points="9 12 12 15 16 10"/></svg>`;
  }
  // Default Arrow
  return `<svg class="log-icon" width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="#64748b" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"/></svg>`;
}

function sanitizeLogText(text) {
  if (!text) return "";
  return text.replace(/[\u{1F300}-\u{1F9FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]/gu, "").trim();
}

function stripLogNoise(logText) {
  return String(logText || "")
    .replace(/^\[[^\]]+\]\s*/, "")
    .replace(/\[(?:Action|Warning|Error|Stop|Summary|Learning|Task)\]\s*/gi, "")
    .replace(/\s*\(Attempt \d+\/\d+\)/gi, "")
    .replace(/\s*\(Step \d+\/\d+\)/gi, "")
    .replace(/\s*\(\d+,\s*\d+\)/gi, "")
    .replace(/\s*:\s*\"/g, ': "')
    .trim();
}

function createCompactActionSummary(logText) {
  const raw = stripLogNoise(logText);
  const text = raw || "";
  const lower = text.toLowerCase();

  if (!text) return "";

  if (lower.includes("click")) return "Clicking";

  if (lower.includes("type") || lower.includes("typing")) {
    const match = text.match(/(?:typing|type)\s*:?\s*["']?(.+?)["']?$/i);
    const typed = match && match[1] ? match[1].trim() : text.replace(/^(?:typing|type)\s*:?\s*/i, "");
    const compact = typed.replace(/\s+/g, " ").slice(0, 32);
    return compact ? `Typing: "${compact}${compact.length >= 32 ? "…" : ""}"` : "Typing";
  }

  if (lower.includes("create") && (lower.includes("doc") || lower.includes("document"))) return "Creating a doc";
  if (lower.includes("gmail") || (lower.includes("email") && lower.includes("draft")) || lower.includes("create email")) return "Creating an email";
  if (lower.includes("create") && lower.includes("folder")) return "Creating a folder";
  if (lower.includes("create") && lower.includes("file")) return "Creating a file";
  if (lower.includes("drive") && lower.includes("read")) return "Reading a file";
  if (lower.includes("inbox") || lower.includes("mail")) return "Checking email";
  if (lower.includes("select")) return "Selecting";
  if (lower.includes("hover")) return "Hovering";
  if (lower.includes("scroll")) return "Scrolling";
  if (lower.includes("navigate") || lower.includes("url")) return "Opening page";
  if (lower.includes("search")) return "Searching";
  if (lower.includes("submit") || lower.includes("enter")) return "Submitting";
  if (lower.includes("analyzing") || lower.includes("screenshot") || lower.includes("reflecting") || lower.includes("learning")) return "Reviewing page";
  if (lower.includes("ready for your confirmation") || lower.includes("finished") || lower.includes("summary")) return "Finished";

  return text.slice(0, 40).replace(/\s+/g, " ");
}

function renderAgentMessageLogs(bubble, logs) {
  let disclosure = bubble.querySelector(".agent-log-disclosure");
  if (!disclosure) {
    disclosure = document.createElement("details");
    disclosure.className = "agent-log-disclosure";

    const summary = document.createElement("summary");
    summary.textContent = "Show detailed logs";
    disclosure.appendChild(summary);
    disclosure.addEventListener("toggle", () => {
      summary.textContent = `${disclosure.open ? "Hide" : "Show"} detailed logs (${logs.length})`;
    });

    const logList = document.createElement("div");
    logList.className = "agent-message-log-list";
    disclosure.appendChild(logList);
    bubble.appendChild(disclosure);
  }

  const summary = disclosure.querySelector("summary");
  summary.textContent = `${disclosure.open ? "Hide" : "Show"} detailed logs (${logs.length})`;
  const logList = disclosure.querySelector(".agent-message-log-list");
  logList.replaceChildren();
  logs.forEach((logText) => {
    const row = document.createElement("div");
    row.className = "agent-message-log-line";
    const icon = document.createElement("span");
    icon.className = "agent-message-log-icon";
    icon.innerHTML = getLogIconSvg(logText);
    const text = document.createElement("span");
    text.textContent = sanitizeLogText(logText);
    row.append(icon, text);
    logList.appendChild(row);
  });
}

function updateLatestAgentBubbleStatus(logText, bubble) {
  const message = createCompactActionSummary(logText);
  if (!message || !bubble) return;

  let statusRow = bubble.querySelector(".message-live-status");
  if (!statusRow) {
    statusRow = document.createElement("div");
    statusRow.className = "message-live-status";
    bubble.appendChild(statusRow);
  }

  statusRow.innerHTML = `${getLogIconSvg(logText)} <span>${sanitizeLogText(message)}</span>`;
}

function getActiveAgentLogMessage(chatId) {
  const chat = chats.find((item) => item.id === chatId);
  if (!chat) return null;

  if (chatId === activeAgentLogChatId && activeAgentLogMessageId) {
    const activeMessage = chat.messages.find((item) => item.id === activeAgentLogMessageId);
    if (activeMessage) return activeMessage;
  }

  return [...chat.messages].reverse().find((item) =>
    item.sender === "agent" && item.text === "Working..." && agentLogsByMessageId.has(item.id)
  ) || null;
}

function getAgentLogBubble(message) {
  if (!message || message.id == null) return null;
  return Array.from(chatContainer.querySelectorAll(".message-bubble.sender-agent"))
    .find((bubble) => bubble.dataset.messageId === message.id) || null;
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === "workspace_operation" && sender.id === chrome.runtime.id && !sender.tab) {
    handleWorkspaceOperation(message)
      .then(sendResponse)
      .catch((error) => {
        console.error("Local workspace operation failed:", error);
        sendResponse({ ok: false, error: error.message });
      });
    return true;
  }

  if (message.action === "agent_task_list") {
    renderAgentTaskList(message.tasks);
  }

  if (message.action === "agent_log") {
    const logText = String(message.text || "");
    const chatId = message.chatId || activeAgentLogChatId || activeChatId;
    const logMessage = getActiveAgentLogMessage(chatId);
    if (logMessage?.id) {
      const agentLogs = agentLogsByMessageId.get(logMessage.id) || [];
      agentLogs.push(String(logText || ""));
      agentLogsByMessageId.set(logMessage.id, agentLogs);
      const bubble = chatId === activeChatId ? getAgentLogBubble(logMessage) : null;
      if (bubble) {
        updateLatestAgentBubbleStatus(logText, bubble);
        renderAgentMessageLogs(bubble, agentLogs);
      }
    }

    // 1. Update the Header Status inside the dropdown
    const stepMatch = logText.match(/Step (\d+) of (\d+)/);
    const statusText = document.getElementById("logs-status-text");
    const agentStatusText = document.getElementById("agent-status-text");
    const indicator = document.querySelector(".status-indicator");

    if (logText.includes("Ready for your confirmation")) {
      if (statusText) statusText.innerText = "Ready for your confirmation";
      if (agentStatusText) agentStatusText.innerText = "Ready for confirmation";
      if (indicator) {
        indicator.classList.remove("active");
        indicator.classList.add("finished");
      }
    } else if (logText.includes("did not produce a visible change") || logText.includes("Retry this step or tell me what to do next") || logText.includes("I could not read this page") || logText.includes("could not decide the next step")) {
      if (statusText) statusText.innerText = "Need a recovery choice";
      if (agentStatusText) agentStatusText.innerText = "Retry or continue manually";
      if (indicator) {
        indicator.classList.add("active");
        indicator.classList.remove("finished");
      }
    } else if (stepMatch) {
      currentStep = parseInt(stepMatch[1]);
      if (statusText) statusText.innerText = `Working, ${currentStep}/${maxSteps}`;
      if (indicator) {
        indicator.classList.add("active");
        indicator.classList.remove("finished");
      }
      if (agentStatusText) agentStatusText.innerText = `Working... (Step ${currentStep}/${maxSteps})`;
    } else if (logText.includes("Screenshot captured") || logText.includes("Analyzing screenshot")) {
      if (statusText) statusText.innerText = `Analyzing screenshot (Step ${currentStep})...`;
      if (agentStatusText) agentStatusText.innerText = `Analyzing... (Step ${currentStep})`;
    }

    // 2. Insert the raw logs STRICTLY inside the dropdown content container
    const logPanel = document.getElementById("log-panel");
    if (logPanel) {
      const iconSvg = getLogIconSvg(logText);
      const cleanText = sanitizeLogText(logText);

      const logLine = document.createElement("div");
      logLine.className = "log-line";
      logLine.style.borderBottom = "1px solid rgba(255,255,255,0.03)";
      logLine.innerHTML = `${iconSvg} <span>${cleanText}</span>`;
      
      logPanel.appendChild(logLine);
      logPanel.scrollTop = logPanel.scrollHeight; // Auto-scroll inside the details box
    }
  }

  // Handle when the agent finishes
  if (message.action === "agent_finished") {
    const statusText = document.getElementById("logs-status-text");
    const agentStatusText = document.getElementById("agent-status-text");
    const indicator = document.querySelector(".status-indicator");

    if (statusText) statusText.innerText = message.awaitingClarification ? "Waiting for your response" : "Completed successfully!";
    if (agentStatusText) agentStatusText.innerText = message.awaitingClarification ? "Awaiting clarification" : "Finished!";
    if (indicator) {
      indicator.classList.remove("active");
      indicator.classList.add("finished");
    }
    setAgentState(false);
    if (message.chatId && message.chatId === activeChatId) {
      objectiveInput.placeholder = message.awaitingClarification
        ? "Answer the agent's question..."
        : getModePlaceholder();
      if (message.awaitingClarification) refreshChatInputPlaceholder();
    }
    if (!message.chatId || message.chatId === activeAgentLogChatId) {
      activeAgentLogChatId = null;
      activeAgentLogMessageId = null;
    }
  }
  if (message.action === "agent_achievement") {
    addMessage(message.text, "agent", message.chatId || activeChatId);
  }
});

// Send the objective to the agent on click
startButton.addEventListener("click", async () => {
  const objective = objectiveInput.value.trim();
  if (!objective) return;

  if (selectedMode !== "code" && shouldUseCodeModeForRequest(objective)) {
    setSelectedMode("code");
  }
  const requestMode = selectedMode;

  if (!googleAccessToken) {
    googleAccessToken = await requestFreshGoogleAccessToken();
    if (!googleAccessToken) return;
  }

  if (!continueCurrentChat && activeChat().messages.length > 0) {
    startNewChat();
  }

  const chat = activeChat();
  const isNewChat = !chat || chat.messages.length === 0;
  if (isNewChat && requestMode === "agent") {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (tab) {
      await chrome.tabs.update(tab.id, { url: "https://www.google.com" });
      await new Promise((resolve) => setTimeout(resolve, 1200));
    }
  }

  if (requestMode === "agent" && !shouldSkipGoogleLandingPageForObjective(objective)) {
    await navigateToGoogleForFirstMessageIfNeeded(objective);
  }

  // Render immediately so task progress is visible even before the service
  // worker sends its first state update.
  renderAgentTaskList(createInitialTaskBoard(objective));
  setAgentState(true); // Switch to "running" view

  // Render & save user message
  addMessage(objective, "user");

  objectiveInput.value = "";
  objectiveInput.style.height = "40px"; // Reset height

  const activeStatusBubble = addMessage("Working...", "agent");
  const activeStatusMessage = activeChat()?.messages[activeChat().messages.length - 1];
  if (activeStatusMessage && activeStatusBubble) {
    agentLogsByMessageId.set(activeStatusMessage.id, []);
    activeAgentLogChatId = activeChatId;
    activeAgentLogMessageId = activeStatusMessage.id;
  }
  if (activeStatusBubble) {
    const liveStatus = activeStatusBubble.querySelector(".message-live-status");
    if (!liveStatus) {
      const statusRow = document.createElement("div");
      statusRow.className = "message-live-status";
      activeStatusBubble.appendChild(statusRow);
    }
  }

  // Broadcast to background.js to kick off the loop
  chrome.runtime.sendMessage({
    action: "start_agent_with_objective",
    objective: objective,
    mode: requestMode,
    accessToken: googleAccessToken,
    chatId: activeChatId,
    chatContext: activeChat().messages
  });
  continueCurrentChat = true;
});

document.querySelectorAll(".prompt-chip[data-prompt]").forEach((promptButton) => {
  promptButton.addEventListener("click", () => {
    objectiveInput.value = promptButton.dataset.prompt;
    objectiveInput.dispatchEvent(new Event("input"));
    objectiveInput.focus();
  });
});

// Auto-resize textarea height based on content
objectiveInput.addEventListener("input", function() {
  this.style.height = "auto";
  this.style.height = this.scrollHeight + "px";
});

objectiveInput.addEventListener("keydown", async (event) => {
  if ((event.key === "Enter" && !event.shiftKey) || ((event.metaKey || event.ctrlKey) && event.key === "Enter")) {
    event.preventDefault();
    startButton.click();
  }
});

// Support CMD/Ctrl + Enter to send and reset height
// Speech Recognition Engine
const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SpeechRecognition) {
  const recognition = new SpeechRecognition();
  recognition.continuous = false;
  recognition.interimResults = false;
  recognition.lang = "en-US";

  let isListening = false;

  micButton.addEventListener("click", () => {
    if (!isListening) {
      recognition.start();
    } else {
      recognition.stop();
    }
  });

  const MIC_ICON_SVG = `<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v1a7 7 0 0 1-14 0v-1"/><line x1="12" x2="12" y1="19" y2="22"/></svg>`;
  const STOP_MIC_ICON_SVG = `<svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><rect x="4" y="4" width="16" height="16" rx="2"/></svg>`;

  recognition.onstart = () => {
    isListening = true;
    micButton.innerHTML = STOP_MIC_ICON_SVG;
    micButton.classList.add("listening");
    objectiveInput.placeholder = "Listening...";
  };

  recognition.onend = () => {
    isListening = false;
    micButton.innerHTML = MIC_ICON_SVG;
    micButton.classList.remove("listening");
    refreshChatInputPlaceholder();
  };

  recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript;
    objectiveInput.value = objectiveInput.value ? objectiveInput.value + " " + transcript : transcript;
    
    // Automatically trigger the height recalculation for the new voice text
    objectiveInput.dispatchEvent(new Event("input"));
  };

  recognition.onerror = (event) => {
    console.error("Speech recognition error:", event.error);
    if (event.error === "not-allowed") {
      chrome.tabs.create({
        url: chrome.runtime.getURL("popup.html?requestMic=true")
      });
    }
  };

// Check if this page was opened as the temporary permission tab
if (window.location.search.includes("requestMic=true")) {
  // Overwrite the body instantly to show a clean permission prompt screen
  document.body.innerHTML = `
    <div style="background:#121214; color:#e4e4e7; font-family:sans-serif; text-align:center; height:100vh; display:flex; flex-direction:column; justify-content:center; align-items:center; margin:0;">
      <h2>Microphone Access Required</h2>
      <p>Please click 'Allow' when prompted to enable voice input for your agent.</p>
    </div>
  `;
  
  navigator.mediaDevices.getUserMedia({ audio: true })
    .then((stream) => {
      // Stop the tracks immediately since we just needed the permission grant
      stream.getTracks().forEach(track => track.stop());
      window.close();
    })
    .catch((err) => {
      console.error("Permission page error:", err);
    });
}
} else {
  micButton.style.display = "none"; // Fallback safety if API isn't supported
}

stopButton.addEventListener("click", () => {
  resolveWorkspaceWriteDecision(false);
  chrome.runtime.sendMessage({ action: "stop_agent" });
  setAgentState(false);
});

// The Drive controls are optional in this side-panel layout. Guard these
// listeners so a layout without that legacy section can still initialize.
if (driveCreateFolderButton) driveCreateFolderButton.addEventListener("click", createDriveFolder);
if (driveCreateFileButton) driveCreateFileButton.addEventListener("click", createDriveDoc);
if (driveListFilesButton) driveListFilesButton.addEventListener("click", listDriveFiles);
agentModeButton.addEventListener("click", () => setSelectedMode("agent"));
codeModeButton.addEventListener("click", () => setSelectedMode("code"));
for (const button of [agentModeButton, codeModeButton]) {
  button.addEventListener("keydown", (event) => {
    if (event.key !== "ArrowLeft" && event.key !== "ArrowRight") return;
    event.preventDefault();
    const nextMode = selectedMode === "agent" ? "code" : "agent";
    setSelectedMode(nextMode);
    (nextMode === "agent" ? agentModeButton : codeModeButton).focus();
  });
}
workspaceMenuButton.addEventListener("click", () => {
  const isOpen = workspaceMenuButton.getAttribute("aria-expanded") === "true";
  workspaceMenu.hidden = isOpen;
  workspaceMenuButton.setAttribute("aria-expanded", String(!isOpen));
  if (!isOpen) chooseWorkspaceButton.focus();
});
chooseWorkspaceButton.addEventListener("click", () => {
  workspaceMenu.hidden = true;
  workspaceMenuButton.setAttribute("aria-expanded", "false");
  chooseWorkspaceFolder();
});
reconnectWorkspaceButton.addEventListener("click", () => {
  workspaceMenu.hidden = true;
  workspaceMenuButton.setAttribute("aria-expanded", "false");
  reconnectWorkspaceFolder();
});
removeWorkspaceButton.addEventListener("click", () => {
  workspaceMenu.hidden = true;
  workspaceMenuButton.setAttribute("aria-expanded", "false");
  disconnectWorkspaceFolder();
});
cancelWorkspaceWriteButton.addEventListener("click", () => resolveWorkspaceWriteDecision(false));
approveWorkspaceWriteButton.addEventListener("click", () => resolveWorkspaceWriteDecision(true));
workspaceWriteOverlay.addEventListener("click", (event) => {
  if (event.target === workspaceWriteOverlay) resolveWorkspaceWriteDecision(false);
});
document.addEventListener("click", (event) => {
  if (!workspaceMenu.contains(event.target) && !workspaceMenuButton.contains(event.target)) {
    workspaceMenu.hidden = true;
    workspaceMenuButton.setAttribute("aria-expanded", "false");
  }
});
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && !workspaceWriteOverlay.hidden) resolveWorkspaceWriteDecision(false);
  if (event.key === "Escape" && !workspaceMenu.hidden) {
    workspaceMenu.hidden = true;
    workspaceMenuButton.setAttribute("aria-expanded", "false");
    workspaceMenuButton.focus();
  }
});

chooseWorkspaceButton.disabled = true;
getStoredWorkspaceHandle()
  .then(async (handle) => {
    workspaceDirectoryHandle = handle;
    await refreshWorkspaceStatus();
  })
  .catch((error) => {
    console.error("Could not restore the local workspace folder:", error);
    workspaceStatus.textContent = `Could not restore the selected folder: ${error.message}`;
  })
  .finally(() => {
    chooseWorkspaceButton.disabled = false;
  });

// ==================== USER-EDITABLE MEMORY ====================
const userMemoryStatusText = document.getElementById("user-memory-status-text");
const userMemoryPanel = document.getElementById("user-memory-panel");
const userMemoryForm = document.getElementById("userMemoryForm");
const userMemoryKey = document.getElementById("userMemoryKey");
const userMemoryValue = document.getElementById("userMemoryValue");
const clearUserMemoryBtn = document.getElementById("clearUserMemoryBtn");

function renderUserMemory(memories) {
  const items = Array.isArray(memories) ? memories : [];
  if (userMemoryStatusText) {
    userMemoryStatusText.textContent = `Memory (${items.length})`;
  }
  if (!userMemoryPanel) return;

  userMemoryPanel.replaceChildren();

  if (items.length === 0) {
    const empty = document.createElement("p");
    empty.className = "empty-learned";
    empty.textContent = "Add details such as your name, preferred airline, budget, or accessibility needs.";
    userMemoryPanel.appendChild(empty);
    return;
  }

  items.forEach((item) => {
    const card = document.createElement("div");
    card.className = "user-memory-card";

    const domainSpan = document.createElement("span");
    domainSpan.className = "memory-key";
    domainSpan.textContent = item.key;

    const textSpan = document.createElement("span");
    textSpan.className = "memory-value";
    textSpan.textContent = item.value;

    const deleteButton = document.createElement("button");
    deleteButton.className = "delete-memory-btn";
    deleteButton.type = "button";
    deleteButton.title = `Delete ${item.key}`;
    deleteButton.textContent = "Remove";
    deleteButton.addEventListener("click", () => {
      chrome.runtime.sendMessage({ action: "delete_user_memory_item", id: item.id }, (response) => {
        if (!chrome.runtime.lastError) renderUserMemory(response?.memories || []);
      });
    });

    card.append(domainSpan, textSpan, deleteButton);
    userMemoryPanel.appendChild(card);
  });
}

chrome.runtime.sendMessage({ action: "get_user_memory" }, (response) => {
  if (!chrome.runtime.lastError) renderUserMemory(response?.memories || []);
});

if (userMemoryForm) {
  userMemoryForm.addEventListener("submit", (e) => {
    e.stopPropagation();
    e.preventDefault();
    chrome.runtime.sendMessage({ action: "add_user_memory_item", key: userMemoryKey.value, value: userMemoryValue.value }, (response) => {
      if (chrome.runtime.lastError || !response?.success) return;
      userMemoryForm.reset();
      renderUserMemory(response.memories || []);
    });
  });
}

if (clearUserMemoryBtn) {
  clearUserMemoryBtn.addEventListener("click", (e) => {
    e.stopPropagation();
    if (confirm("Clear all saved user memory?")) {
      chrome.runtime.sendMessage({ action: "clear_user_memory" }, (response) => {
        if (!chrome.runtime.lastError) renderUserMemory(response?.memories || []);
      });
    }
  });
}
